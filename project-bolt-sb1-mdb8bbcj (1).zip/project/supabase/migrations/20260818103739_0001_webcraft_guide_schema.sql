/*
# WebCraft Guide — Core Schema

## Overview
Creates the full schema for WebCraft Guide, a professional educational technology
publication focused on AI tutorials, web development, SEO, website building, and tools.

## Tables
1. authors — Article author profiles (editorial metadata, not auth users).
2. categories — Article categories (AI, Web Development, SEO, etc.).
3. tags — Tag taxonomy for articles.
4. articles — Editorial articles (full SEO + publishing workflow).
5. article_tags — Join table: many-to-many articles ↔ tags.
6. article_media — Media library entries (uploaded images/files).
7. tools — Registry of free online tools (display metadata only).
8. subscribers — Email newsletter subscribers (single field, no account needed).
9. contact_messages — Messages from the public contact form.
10. site_settings — Singleton-style site configuration row.

## Security (RLS)
- authors, categories, tags, tools, site_settings: public read; authenticated write.
- articles: public read only published/scheduled-due/sample; authenticated full access.
- article_tags, article_media: public read; authenticated write.
- subscribers: anon may insert (newsletter signup); only authenticated can read/delete.
- contact_messages: anon may insert; only authenticated can read/update/delete.
- Admin authorization additionally enforced client-side by requiring sign-in.

## Notes
1. site_settings seeded with one default row (id=1).
2. categories seeded with 6 site categories + JavaScript.
3. tools seeded with 8 tool registry entries.
4. No hard-coded passwords or secrets.
*/

-- AUTHORS
CREATE TABLE IF NOT EXISTS authors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  bio text,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE authors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_authors" ON authors;
CREATE POLICY "public_read_authors" ON authors FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_authors" ON authors;
CREATE POLICY "auth_insert_authors" ON authors FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_authors" ON authors;
CREATE POLICY "auth_update_authors" ON authors FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_authors" ON authors;
CREATE POLICY "auth_delete_authors" ON authors FOR DELETE
  TO authenticated USING (true);

-- CATEGORIES
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_categories" ON categories;
CREATE POLICY "public_read_categories" ON categories FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_categories" ON categories;
CREATE POLICY "auth_insert_categories" ON categories FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_categories" ON categories;
CREATE POLICY "auth_update_categories" ON categories FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_categories" ON categories;
CREATE POLICY "auth_delete_categories" ON categories FOR DELETE
  TO authenticated USING (true);

-- TAGS
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_tags" ON tags;
CREATE POLICY "public_read_tags" ON tags FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_tags" ON tags;
CREATE POLICY "auth_insert_tags" ON tags FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_tags" ON tags;
CREATE POLICY "auth_update_tags" ON tags FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_tags" ON tags;
CREATE POLICY "auth_delete_tags" ON tags FOR DELETE
  TO authenticated USING (true);

-- ARTICLES
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  excerpt text,
  content jsonb NOT NULL DEFAULT '[]'::jsonb,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  author_id uuid REFERENCES authors(id) ON DELETE SET NULL,
  featured_image_url text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','scheduled')),
  published_at timestamptz,
  updated_at timestamptz DEFAULT now(),
  reading_time_minutes integer DEFAULT 1,
  seo_title text,
  meta_description text,
  canonical_url text,
  og_image_url text,
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_articles" ON articles;
CREATE POLICY "public_read_articles" ON articles FOR SELECT
  TO anon, authenticated
  USING (
    status = 'published'
    OR (status = 'scheduled' AND published_at IS NOT NULL AND published_at <= now())
    OR is_sample = true
  );
DROP POLICY IF EXISTS "auth_read_articles" ON articles;
CREATE POLICY "auth_read_articles" ON articles FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_articles" ON articles;
CREATE POLICY "auth_insert_articles" ON articles FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_articles" ON articles;
CREATE POLICY "auth_update_articles" ON articles FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_articles" ON articles;
CREATE POLICY "auth_delete_articles" ON articles FOR DELETE
  TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_category_id ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_author_id ON articles(author_id);

-- ARTICLE_TAGS
CREATE TABLE IF NOT EXISTS article_tags (
  article_id uuid NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);
ALTER TABLE article_tags ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_article_tags" ON article_tags;
CREATE POLICY "public_read_article_tags" ON article_tags FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_article_tags" ON article_tags;
CREATE POLICY "auth_insert_article_tags" ON article_tags FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_article_tags" ON article_tags;
CREATE POLICY "auth_delete_article_tags" ON article_tags FOR DELETE
  TO authenticated USING (true);

-- ARTICLE_MEDIA
CREATE TABLE IF NOT EXISTS article_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  file_name text,
  file_type text,
  width integer,
  height integer,
  size_bytes bigint,
  alt_text text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE article_media ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_article_media" ON article_media;
CREATE POLICY "public_read_article_media" ON article_media FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_article_media" ON article_media;
CREATE POLICY "auth_insert_article_media" ON article_media FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_article_media" ON article_media;
CREATE POLICY "auth_update_article_media" ON article_media FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_article_media" ON article_media;
CREATE POLICY "auth_delete_article_media" ON article_media FOR DELETE
  TO authenticated USING (true);

-- TOOLS (registry metadata only)
CREATE TABLE IF NOT EXISTS tools (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  icon text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE tools ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_tools" ON tools;
CREATE POLICY "public_read_tools" ON tools FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_tools" ON tools;
CREATE POLICY "auth_insert_tools" ON tools FOR INSERT
  TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_tools" ON tools;
CREATE POLICY "auth_update_tools" ON tools FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_tools" ON tools;
CREATE POLICY "auth_delete_tools" ON tools FOR DELETE
  TO authenticated USING (true);

-- SUBSCRIBERS
CREATE TABLE IF NOT EXISTS subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE subscribers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_insert_subscribers" ON subscribers;
CREATE POLICY "anon_insert_subscribers" ON subscribers FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_read_subscribers" ON subscribers;
CREATE POLICY "auth_read_subscribers" ON subscribers FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_delete_subscribers" ON subscribers;
CREATE POLICY "auth_delete_subscribers" ON subscribers FOR DELETE
  TO authenticated USING (true);

-- CONTACT_MESSAGES
CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_insert_contact_messages" ON contact_messages;
CREATE POLICY "anon_insert_contact_messages" ON contact_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_read_contact_messages" ON contact_messages;
CREATE POLICY "auth_read_contact_messages" ON contact_messages FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_update_contact_messages" ON contact_messages;
CREATE POLICY "auth_update_contact_messages" ON contact_messages FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_contact_messages" ON contact_messages;
CREATE POLICY "auth_delete_contact_messages" ON contact_messages FOR DELETE
  TO authenticated USING (true);

-- SITE_SETTINGS (single row, id fixed to 1)
CREATE TABLE IF NOT EXISTS site_settings (
  id bigint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  site_name text NOT NULL DEFAULT 'WebCraft Guide',
  site_description text NOT NULL DEFAULT 'Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.',
  logo_url text,
  favicon_url text,
  contact_email text,
  social_links jsonb NOT NULL DEFAULT '{}'::jsonb,
  google_analytics_id text,
  search_console_verification text,
  adsense_publisher_id text,
  adsense_slot_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  ads_enabled boolean NOT NULL DEFAULT false,
  footer_text text NOT NULL DEFAULT 'Learn AI, web development, SEO, and website building.',
  default_seo_title text NOT NULL DEFAULT 'WebCraft Guide — Learn AI & Web Development',
  default_meta_description text NOT NULL DEFAULT 'Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.',
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_site_settings" ON site_settings;
CREATE POLICY "public_read_site_settings" ON site_settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "auth_update_site_settings" ON site_settings;
CREATE POLICY "auth_update_site_settings" ON site_settings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- SEED: site_settings default row
INSERT INTO site_settings (id) VALUES (1)
ON CONFLICT (id) DO NOTHING;

-- SEED: categories
INSERT INTO categories (name, slug, description, icon) VALUES
('AI', 'ai', 'AI tools, prompting, coding, productivity, and AI website builders.', 'Sparkles'),
('Web Development', 'web-development', 'HTML, CSS, JavaScript, React, APIs, databases, and hosting.', 'Code2'),
('Website Building', 'website-building', 'Website builders, forms, booking systems, admin panels, domains, and hosting.', 'LayoutTemplate'),
('SEO', 'seo', 'SEO basics, technical SEO, on-page SEO, Search Console, and website performance.', 'Search'),
('Website Business', 'website-business', 'Finding clients, website pricing, client websites, maintenance, and local business websites.', 'Briefcase'),
('JavaScript', 'javascript', 'JavaScript tutorials, patterns, and beginner-friendly examples.', 'Braces')
ON CONFLICT (slug) DO NOTHING;

-- SEED: tools registry
INSERT INTO tools (name, slug, description, icon) VALUES
('Word Counter', 'word-counter', 'Count words, characters, sentences, and paragraphs instantly.', 'Type'),
('Percentage Calculator', 'percentage-calculator', 'Calculate percentages, increases, and decreases.', 'Percent'),
('Text Case Converter', 'text-case-converter', 'Convert text to UPPERCASE, lowercase, Title Case, and Sentence case.', 'CaseSensitive'),
('JSON Formatter', 'json-formatter', 'Format, validate, and beautify JSON with clear error messages.', 'Braces'),
('HTML Formatter', 'html-formatter', 'Format and beautify basic HTML markup.', 'Code2'),
('Color Converter', 'color-converter', 'Convert colors between HEX, RGB, and HSL with a live preview.', 'Palette'),
('QR Code Generator', 'qr-code-generator', 'Generate QR codes locally in your browser from text or a URL.', 'QrCode'),
('Image Size Calculator', 'image-size-calculator', 'See image width, height, aspect ratio, file size, and type.', 'Image')
ON CONFLICT (slug) DO NOTHING;
