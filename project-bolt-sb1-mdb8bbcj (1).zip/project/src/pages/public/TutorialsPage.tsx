import { useEffect, useState } from 'react';
import type { Article } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { ArticleCard } from '@/components/ArticleCard';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useSeo } from '@/context/SeoContext';

export function TutorialsPage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  useSeo({
    title: 'Tutorials — WebCraft Guide',
    description: 'Browse all WebCraft Guide tutorials on AI, web development, SEO, website building, and online tools.',
    canonicalPath: '/tutorials',
  });

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('articles')
        .select('*, category:categories(*), author:authors(*)')
        .or('status.eq.published,is_sample.eq.true')
        .order('published_at', { ascending: false, nullsFirst: false });
      setArticles((data ?? []) as Article[]);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Tutorials' }]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">Tutorials</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">Practical, beginner-friendly guides across AI, web development, SEO, and more.</p>
      {loading ? (
        <p className="mt-8 text-slate-500">Loading…</p>
      ) : articles.length === 0 ? (
        <p className="mt-8 text-slate-500">No tutorials published yet.</p>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((a) => <ArticleCard key={a.id} article={a} />)}
        </div>
      )}
    </div>
  );
}
