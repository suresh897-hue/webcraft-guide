import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, ArrowLeft, ArrowRight, User } from 'lucide-react';
import type { Article } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { ArticleContent, extractHeadings } from '@/components/ArticleContent';
import { ArticleCard } from '@/components/ArticleCard';
import { Breadcrumbs, SocialShare } from '@/components/Breadcrumbs';
import { NotFoundPage } from '@/components/ErrorPages';
import { TopAd, ArticleAd, SidebarAd, BottomAd } from '@/components/Ads';
import { useSeo, SITE_ORIGIN } from '@/context/SeoContext';
import { formatDate } from '@/lib/format';

export function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [related, setRelated] = useState<Article[]>([]);
  const [prev, setPrev] = useState<Article | null>(null);
  const [next, setNext] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    (async () => {
      const { data } = await supabase
        .from('articles')
        .select('*, category:categories(*), author:authors(*)')
        .eq('slug', slug)
        .maybeSingle();
      const a = data as Article | null;
      setArticle(a);
      if (a?.category_id) {
        const { data: rData } = await supabase
          .from('articles')
          .select('*, category:categories(*), author:authors(*)')
          .eq('category_id', a.category_id)
          .neq('id', a.id)
          .or('status.eq.published,is_sample.eq.true')
          .limit(3);
        setRelated((rData ?? []) as Article[]);
        const { data: allInCat } = await supabase
          .from('articles')
          .select('id, title, slug')
          .eq('category_id', a.category_id)
          .or('status.eq.published,is_sample.eq.true')
          .order('published_at', { ascending: true, nullsFirst: false });
        const list = (allInCat ?? []) as { id: string; title: string; slug: string; published_at?: string | null }[];
        const idx = list.findIndex((x) => x.id === a.id);
        if (idx > 0) setPrev(list[idx - 1] as Article);
        else setPrev(null);
        if (idx >= 0 && idx < list.length - 1) setNext(list[idx + 1] as Article);
        else setNext(null);
      }
      setLoading(false);
    })();
  }, [slug]);

  useSeo({
    title: article?.seo_title ?? article?.title ?? 'Article',
    description: article?.meta_description ?? article?.excerpt ?? '',
    canonicalPath: article?.canonical_url ?? `/tutorials/${slug}`,
    ogImage: article?.og_image_url ?? article?.featured_image_url ?? undefined,
    ogType: 'article',
    jsonLd: article ? {
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: article.title,
      description: article.meta_description ?? article.excerpt ?? '',
      datePublished: article.published_at,
      dateModified: article.updated_at,
      author: article.author ? { '@type': 'Person', name: article.author.name } : undefined,
      image: article.featured_image_url ?? undefined,
      mainEntityOfPage: `${SITE_ORIGIN}/tutorials/${article.slug}`,
    } : undefined,
  });

  if (loading) return <div className="mx-auto max-w-3xl px-4 py-20 text-slate-500">Loading…</div>;
  if (!article) return <NotFoundPage message="Article not found" />;

  const headings = extractHeadings(article.content);
  const categoryName = article.category?.name ?? 'Uncategorized';
  const categorySlug = article.category?.slug ?? 'tutorials';

  return (
    <article className="mx-auto max-w-6xl px-4 py-10">
      <Breadcrumbs items={[
        { label: 'Home', to: '/' },
        { label: 'Tutorials', to: '/tutorials' },
        { label: categoryName, to: `/${categorySlug}` },
        { label: article.title },
      ]} />

      <TopAd />

      <header className="mt-6 max-w-3xl">
        <Link to={`/${categorySlug}`} className="text-sm font-medium text-blue-600 hover:underline dark:text-blue-400">{categoryName}</Link>
        {article.is_sample && (
          <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
            Sample Article — Demo Content
          </span>
        )}
        <h1 className="mt-2 text-3xl font-bold leading-tight text-slate-900 dark:text-white md:text-4xl">{article.title}</h1>
        {article.excerpt && <p className="mt-3 text-lg text-slate-600 dark:text-slate-300">{article.excerpt}</p>}
        <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
          {article.author && (
            <span className="flex items-center gap-1"><User className="h-4 w-4" /> {article.author.name}</span>
          )}
          <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {formatDate(article.published_at)}</span>
          <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {article.reading_time_minutes} min read</span>
        </div>
      </header>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_280px]">
        <div className="min-w-0">
          {article.featured_image_url && (
            <img src={article.featured_image_url} alt={article.title} className="mb-6 w-full rounded-2xl" />
          )}
          <ArticleContent blocks={article.content} />
          <p className="mt-8 border-t border-slate-200 pt-4 text-sm text-slate-500 dark:border-slate-800 dark:text-slate-400">
            Last updated: {formatDate(article.updated_at)}
          </p>
          <div className="mt-4"><SocialShare article={article} /></div>
          <ArticleAd />

          {/* Prev / Next */}
          <nav className="mt-8 grid gap-4 sm:grid-cols-2">
            {prev ? (
              <Link to={`/tutorials/${prev.slug}`} className="group rounded-xl border border-slate-200 p-4 hover:border-blue-400 dark:border-slate-800">
                <span className="flex items-center gap-1 text-xs text-slate-500"><ArrowLeft className="h-3 w-3" /> Previous</span>
                <span className="mt-1 block font-medium text-slate-900 group-hover:text-blue-600 dark:text-white">{prev.title}</span>
              </Link>
            ) : <div />}
            {next ? (
              <Link to={`/tutorials/${next.slug}`} className="group rounded-xl border border-slate-200 p-4 text-right hover:border-blue-400 dark:border-slate-800">
                <span className="flex items-center justify-end gap-1 text-xs text-slate-500">Next <ArrowRight className="h-3 w-3" /></span>
                <span className="mt-1 block font-medium text-slate-900 group-hover:text-blue-600 dark:text-white">{next.title}</span>
              </Link>
            ) : <div />}
          </nav>

          {/* Related */}
          {related.length > 0 && (
            <section className="mt-12">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Related articles</h2>
              <div className="mt-4 grid gap-6 sm:grid-cols-2">
                {related.map((r) => <ArticleCard key={r.id} article={r} />)}
              </div>
            </section>
          )}
        </div>

        <aside className="lg:sticky lg:top-20 lg:self-start">
          {headings.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">Table of contents</h2>
              <ul className="mt-3 space-y-1 text-sm">
                {headings.map((h) => (
                  <li key={h.id} className={h.level === 3 ? 'pl-3' : ''}>
                    <a href={`#${h.id}`} className="text-slate-600 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400">{h.text}</a>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="mt-6"><SidebarAd /></div>
        </aside>
      </div>

      <BottomAd />
    </article>
  );
}
