import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { Tool } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { getIcon } from '@/lib/icons';
import { useSeo } from '@/context/SeoContext';

const fallbackTools: { name: string; slug: string; description: string; icon: string }[] = [
  { name: 'Word Counter', slug: 'word-counter', description: 'Count words, characters, sentences, and paragraphs instantly.', icon: 'Type' },
  { name: 'Percentage Calculator', slug: 'percentage-calculator', description: 'Calculate percentages, increases, and decreases.', icon: 'Percent' },
  { name: 'Text Case Converter', slug: 'text-case-converter', description: 'Convert text to UPPERCASE, lowercase, Title Case, and Sentence case.', icon: 'CaseSensitive' },
  { name: 'JSON Formatter', slug: 'json-formatter', description: 'Format, validate, and beautify JSON with clear error messages.', icon: 'Braces' },
  { name: 'HTML Formatter', slug: 'html-formatter', description: 'Format and beautify basic HTML markup.', icon: 'Code2' },
  { name: 'Color Converter', slug: 'color-converter', description: 'Convert colors between HEX, RGB, and HSL with a live preview.', icon: 'Palette' },
  { name: 'QR Code Generator', slug: 'qr-code-generator', description: 'Generate QR codes locally in your browser from text or a URL.', icon: 'QrCode' },
  { name: 'Image Size Calculator', slug: 'image-size-calculator', description: 'See image width, height, aspect ratio, file size, and type.', icon: 'Image' },
];

export function ToolsPage() {
  const [tools, setTools] = useState<(Tool | typeof fallbackTools[number])[]>(fallbackTools);
  useSeo({
    title: 'Free Tools — WebCraft Guide',
    description: 'Fast, private, browser-based tools: word counter, percentage calculator, JSON formatter, QR code generator, and more.',
    canonicalPath: '/tools',
  });

  useEffect(() => {
    supabase.from('tools').select('*').eq('is_active', true).order('created_at').then(({ data }) => {
      if (data && data.length > 0) setTools(data as Tool[]);
    });
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Tools' }]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">Free Tools</h1>
      <p className="mt-2 max-w-2xl text-slate-600 dark:text-slate-400">Lightweight, privacy-friendly tools that run entirely in your browser. No uploads, no tracking.</p>
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((tool) => {
          const Icon = getIcon(tool.icon);
          return (
            <Link
              key={tool.slug}
              to={`/tools/${tool.slug}`}
              className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400">
                <Icon className="h-6 w-6" />
              </span>
              <h2 className="mt-3 text-lg font-semibold text-slate-900 dark:text-white">{tool.name}</h2>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{tool.description}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-blue-600 group-hover:gap-2 dark:text-blue-400">
                Open tool <ArrowRight className="h-4 w-4" />
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
