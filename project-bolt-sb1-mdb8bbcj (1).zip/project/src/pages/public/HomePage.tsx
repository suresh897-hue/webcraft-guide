import { Link } from 'react-router-dom';
import { ArrowRight, Wrench, BookOpen } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Article, Category, Tool } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { ArticleCard } from '@/components/ArticleCard';
import { getIcon } from '@/lib/icons';
import { useSeo, SITE_ORIGIN } from '@/context/SeoContext';

export function HomePage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [loading, setLoading] = useState(true);

  useSeo({
    title: 'WebCraft Guide — Learn AI & Web Development',
    description: 'Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.',
    canonicalPath: '/',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'WebCraft Guide',
      url: SITE_ORIGIN,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${SITE_ORIGIN}/search?q={search_term_string}`,
        'query-input': 'required name=search_term_string',
      },
    },
  });

  useEffect(() => {
    (async () => {
      const [{ data: aData }, { data: cData }, { data: tData }] = await Promise.all([
        supabase
          .from('articles')
          .select('*, category:categories(*), author:authors(*)')
          .or('status.eq.published,is_sample.eq.true')
          .order('published_at', { ascending: false, nullsFirst: false })
          .limit(6),
        supabase.from('categories').select('*').order('created_at'),
        supabase.from('tools').select('*').eq('is_active', true).order('created_at'),
      ]);
      setArticles((aData ?? []) as Article[]);
      setCategories((cData ?? []) as Category[]);
      setTools((tData ?? []) as Tool[]);
      setLoading(false);
    })();
  }, []);

  const featuredCategories = categories.filter((c) =>
    ['ai', 'web-development', 'javascript', 'website-building', 'seo', 'website-business'].includes(c.slug)
  );

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-b from-blue-50/60 to-white dark:border-slate-800 dark:from-slate-900 dark:to-slate-950">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-blue-600 dark:text-blue-400">WebCraft Guide</p>
            <h1 className="mt-3 text-4xl font-bold leading-tight text-slate-900 dark:text-white md:text-5xl">
              Learn AI &amp; Web Development — Simply
            </h1>
            <p className="mt-4 max-w-lg text-lg text-slate-600 dark:text-slate-300">
              Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/tutorials" className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700">
                <BookOpen className="h-4 w-4" /> Explore Tutorials
              </Link>
              <Link to="/tools" className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">
                <Wrench className="h-4 w-4" /> Free Tools
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] overflow-hidden rounded-2xl border border-slate-200 shadow-sm dark:border-slate-800">
              <img
                src="https://images.pexels.com/photos/97077/pexels-photo-97077.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Abstract programming code on a screen"
                className="h-full w-full object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured tutorials */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Featured Tutorials</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Fresh guides from the WebCraft Guide library.</p>
          </div>
          <Link to="/tutorials" className="hidden text-sm font-medium text-blue-600 hover:underline dark:text-blue-400 sm:inline">View all →</Link>
        </div>
        {loading ? (
          <p className="text-slate-500">Loading…</p>
        ) : articles.length === 0 ? (
          <p className="text-slate-500">No tutorials yet. Check back soon.</p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {articles.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        )}
      </section>

      {/* Categories */}
      <section className="border-y border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/50">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Popular Categories</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Browse by topic.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {featuredCategories.map((cat) => {
              const Icon = getIcon(cat.icon);
              return (
                <Link
                  key={cat.id}
                  to={`/${cat.slug}`}
                  className="group flex items-start gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">{cat.name}</h3>
                    <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{cat.description}</p>
                    <span className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-blue-600 group-hover:gap-2 dark:text-blue-400">
                      Explore <ArrowRight className="h-4 w-4" />
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tools preview */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Free Tools</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Fast, private, and entirely in your browser.</p>
          </div>
          <Link to="/tools" className="hidden text-sm font-medium text-blue-600 hover:underline dark:text-blue-400 sm:inline">All tools →</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {tools.map((tool) => {
            const Icon = getIcon(tool.icon);
            return (
              <Link
                key={tool.id}
                to={`/tools/${tool.slug}`}
                className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="mt-3 font-semibold text-slate-900 dark:text-white">{tool.name}</h3>
                <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{tool.description}</p>
              </Link>
            );
          })}
        </div>
      </section>
    </div>
  );
}
