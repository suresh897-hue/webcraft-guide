import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon } from 'lucide-react';
import type { Article } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { ArticleCard } from '@/components/ArticleCard';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useSeo } from '@/context/SeoContext';

export function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get('q') ?? '';
  const [results, setResults] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);

  useSeo({
    title: q ? `Search: ${q} — WebCraft Guide` : 'Search — WebCraft Guide',
    description: 'Search WebCraft Guide tutorials and guides.',
    canonicalPath: `/search?q=${encodeURIComponent(q)}`,
  });

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    setLoading(true);
    (async () => {
      const term = `%${q.trim()}%`;
      const { data } = await supabase
        .from('articles')
        .select('*, category:categories(*), author:authors(*)')
        .or('status.eq.published,is_sample.eq.true')
        .or(`title.ilike.${term},excerpt.ilike.${term}`)
        .order('published_at', { ascending: false, nullsFirst: false });
      // Also search content jsonb text via client-side filter (Supabase ilike doesn't reach jsonb)
      const filtered = (data ?? []).filter((a) => {
        const contentText = (a as Article).content
          .map((b) => ('text' in b ? b.text : 'items' in b ? b.items.join(' ') : ''))
          .join(' ');
        const categoryMatch = (a as Article).category?.name?.toLowerCase().includes(q.toLowerCase());
        const tagMatch = ((a as Article).tags ?? []).some((t) => t.name.toLowerCase().includes(q.toLowerCase()));
        return (
          (a as Article).title?.toLowerCase().includes(q.toLowerCase()) ||
          (a as Article).excerpt?.toLowerCase().includes(q.toLowerCase()) ||
          contentText.toLowerCase().includes(q.toLowerCase()) ||
          categoryMatch || tagMatch
        );
      });
      setResults(filtered as Article[]);
      setLoading(false);
    })();
  }, [q]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Search' }]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">Search</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">
        {q ? <>Results for <span className="font-semibold">“{q}”</span> — {loading ? '…' : `${results.length} found`}</> : 'Enter a search term above.'}
      </p>

      <form className="mt-6 flex max-w-xl items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 dark:border-slate-700">
        <SearchIcon className="h-5 w-5 text-slate-400" />
        <input
          defaultValue={q}
          name="q"
          placeholder="Search tutorials, guides, tools…"
          className="flex-1 bg-transparent text-sm outline-none dark:text-white"
        />
        <button className="rounded-lg bg-blue-600 px-3 py-1 text-sm font-medium text-white hover:bg-blue-700">Search</button>
      </form>

      <div className="mt-8">
        {loading ? (
          <p className="text-slate-500">Searching…</p>
        ) : q && results.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 p-8 text-center dark:border-slate-800">
            <p className="text-lg font-semibold text-slate-900 dark:text-white">No articles found.</p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Try a broader search, or browse a category:</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {['ai', 'web-development', 'seo', 'tools'].map((s) => (
                <Link key={s} to={`/${s}`} className="rounded-full border border-slate-200 px-3 py-1 text-sm text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800">
                  {s.replace('-', ' ')}
                </Link>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {results.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        )}
      </div>
    </div>
  );
}
