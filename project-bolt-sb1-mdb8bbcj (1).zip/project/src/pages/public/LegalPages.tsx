import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useSeo } from '@/context/SeoContext';

function LegalLayout({ title, crumbs, intro, children }: { title: string; crumbs: { label: string; to?: string }[]; intro?: string; children: React.ReactNode }) {
  useSeo({ title: `${title} — WebCraft Guide`, description: title, canonicalPath: `/${crumbs[crumbs.length - 1].label.toLowerCase().replace(/\s+/g, '-')}` });
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, ...crumbs]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">{title}</h1>
      {intro && <p className="mt-3 text-slate-600 dark:text-slate-400">{intro}</p>}
      <div className="mt-6 space-y-6 text-slate-700 dark:text-slate-300">{children}</div>
      <p className="mt-10 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
        This page uses editable placeholders. Replace the bracketed sections with your actual legal details before relying on them.
      </p>
    </div>
  );
}

export function PrivacyPolicyPage() {
  return (
    <LegalLayout title="Privacy Policy" crumbs={[{ label: 'Privacy Policy' }]} intro="How WebCraft Guide handles your information.">
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Cookies</h2>
        <p className="mt-2">This site may use cookies to remember preferences (such as dark mode) and, if enabled by the site owner, analytics and advertising. You can disable cookies in your browser settings.</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Analytics</h2>
        <p className="mt-2">If the site owner configures Google Analytics, anonymous usage data may be collected. No analytics scripts run unless a Measurement ID is configured.</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Advertising</h2>
        <p className="mt-2">If advertising is enabled, third-party ad partners may use cookies to serve relevant ads. No real ad code is inserted until valid credentials are provided by the site owner.</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Third-party services</h2>
        <p className="mt-2">This site may use third-party hosting, authentication, and storage providers. [List specific providers and their purposes here.]</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Contact forms</h2>
        <p className="mt-2">When you submit the contact form, your name, email, subject, and message are stored securely so the site owner can respond. They are never shown publicly.</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Data collection</h2>
        <p className="mt-2">We do not require personal information to browse the public site. The only information collected is what you voluntarily provide through forms (e.g. contact, newsletter).</p>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Your rights</h2>
        <p className="mt-2">You may request access to, correction of, or deletion of any personal data you have submitted. Contact [editable contact email] to make a request.</p>
      </section>
    </LegalLayout>
  );
}

export function TermsPage() {
  return (
    <LegalLayout title="Terms of Service" crumbs={[{ label: 'Terms' }]} intro="The terms for using WebCraft Guide.">
      <p>By using this website you agree to these terms. Content is provided for educational purposes only and without warranty.</p>
      <p>You agree not to misuse the site, its tools, or its forms. The site owner is not liable for damages arising from use of the content or tools.</p>
      <p>[Add jurisdiction and specific legal details here before relying on this page.]</p>
    </LegalLayout>
  );
}

export function CookiePolicyPage() {
  return (
    <LegalLayout title="Cookie Policy" crumbs={[{ label: 'Cookie Policy' }]} intro="How WebCraft Guide uses cookies.">
      <p>This site uses cookies to remember your preferences (such as dark mode) and, if enabled, for analytics and advertising.</p>
      <p>You can control cookies in your browser settings. Disabling cookies may affect some features.</p>
      <p>[List specific cookies used here.]</p>
    </LegalLayout>
  );
}
