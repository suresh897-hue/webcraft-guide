import { useState } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useSeo } from '@/context/SeoContext';
import { supabase } from '@/lib/supabase';

export function ContactPage() {
  useSeo({
    title: 'Contact — WebCraft Guide',
    description: 'Get in touch with the WebCraft Guide team.',
    canonicalPath: '/contact',
  });
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.subject.trim()) e.subject = 'Subject is required';
    if (!form.message.trim()) e.message = 'Message is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setStatus('submitting');
    const { error } = await supabase.from('contact_messages').insert({
      name: form.name.trim(),
      email: form.email.trim(),
      subject: form.subject.trim(),
      message: form.message.trim(),
    });
    if (error) setStatus('error');
    else { setStatus('success'); setForm({ name: '', email: '', subject: '', message: '' }); }
  };

  const field = (name: keyof typeof form, label: string, type = 'text') => (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
      <input
        type={type}
        value={form[name]}
        onChange={(e) => setForm({ ...form, [name]: e.target.value })}
        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
      />
      {errors[name] && <p className="mt-1 text-xs text-red-600">{errors[name]}</p>}
    </div>
  );

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Contact' }]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">Contact</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">Send us a message and we'll get back to you.</p>

      {status === 'success' && (
        <div className="mt-6 rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-900 dark:bg-green-900/30 dark:text-green-300">
          Thanks — your message has been received.
        </div>
      )}
      {status === 'error' && (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-900 dark:bg-red-900/30 dark:text-red-300">
          Something went wrong sending your message. Please try again later.
        </div>
      )}

      <form onSubmit={submit} className="mt-6 space-y-4">
        {field('name', 'Name')}
        {field('email', 'Email', 'email')}
        {field('subject', 'Subject')}
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
          <textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            rows={5}
            className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
          />
          {errors.message && <p className="mt-1 text-xs text-red-600">{errors.message}</p>}
        </div>
        <button
          type="submit"
          disabled={status === 'submitting'}
          className="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
        >
          {status === 'submitting' ? 'Sending…' : 'Send message'}
        </button>
      </form>
    </div>
  );
}
