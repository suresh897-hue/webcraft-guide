import { useState } from 'react';
import { Copy, Trash2 } from 'lucide-react';
import { useSeo } from '@/context/SeoContext';

export function WordCounterTool() {
  useSeo({ title: 'Word Counter — WebCraft Guide', description: 'Count words, characters, sentences, and paragraphs instantly.', canonicalPath: '/tools/word-counter' });
  const [text, setText] = useState('');
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const charsNoSpaces = text.replace(/\s/g, '').length;
  const sentences = text.trim() ? (text.match(/[.!?]+(\s|$)/g) ?? []).length || (text.trim() ? 1 : 0) : 0;
  const paragraphs = text.trim() ? text.split(/\n+/).filter((p) => p.trim()).length : 0;

  const stats = [
    { label: 'Words', value: words },
    { label: 'Characters', value: chars },
    { label: 'Characters (no spaces)', value: charsNoSpaces },
    { label: 'Sentences', value: sentences },
    { label: 'Paragraphs', value: paragraphs },
  ];

  return (
    <ToolShell title="Word Counter" description="Instantly count words, characters, sentences, and paragraphs.">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={10}
        placeholder="Paste or type your text here…"
        className="w-full rounded-xl border border-slate-300 p-4 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
      />
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-slate-900">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{s.value}</div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <button onClick={() => setText('')} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Trash2 className="h-4 w-4" /> Clear</button>
        <button onClick={() => navigator.clipboard.writeText(text)} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Copy className="h-4 w-4" /> Copy</button>
      </div>
    </ToolShell>
  );
}

export function PercentageCalculatorTool() {
  useSeo({ title: 'Percentage Calculator — WebCraft Guide', description: 'Calculate percentage of a number, increase, and decrease.', canonicalPath: '/tools/percentage-calculator' });
  const [base, setBase] = useState('');
  const [pct, setPct] = useState('');
  const [incBase, setIncBase] = useState('');
  const [incPct, setIncPct] = useState('');
  const [decBase, setDecBase] = useState('');
  const [decPct, setDecPct] = useState('');

  const num = (v: string) => (v.trim() === '' ? NaN : Number(v));
  const ofResult = !isNaN(num(base)) && !isNaN(num(pct)) ? (num(base) * num(pct)) / 100 : null;
  const incResult = !isNaN(num(incBase)) && !isNaN(num(incPct)) ? num(incBase) * (1 + num(incPct) / 100) : null;
  const decResult = !isNaN(num(decBase)) && !isNaN(num(decPct)) ? num(decBase) * (1 - num(decPct) / 100) : null;

  const row = (label: string, a: [string, string, (v: string) => void], b: [string, string, (v: string) => void], result: number | null, suffix = '') => (
    <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{label}</h3>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
        <input value={a[0]} onChange={(e) => a[2](e.target.value)} inputMode="decimal" placeholder={a[1]} className="w-32 rounded-lg border border-slate-300 px-2 py-1.5 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        <span className="text-slate-500">{label.includes('of') ? '% of' : label.includes('Increase') ? '+' : '−'}</span>
        <input value={b[0]} onChange={(e) => b[2](e.target.value)} inputMode="decimal" placeholder={b[1]} className="w-24 rounded-lg border border-slate-300 px-2 py-1.5 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        <span className="text-slate-500">%</span>
      </div>
      <p className="mt-3 text-sm">
        Result: <span className="font-semibold text-blue-600 dark:text-blue-400">{result === null ? '—' : `${Number.isFinite(result) ? result.toFixed(2).replace(/\.00$/, '') : '—'}${suffix}`}</span>
      </p>
    </div>
  );

  return (
    <ToolShell title="Percentage Calculator" description="Calculate percentages, increases, and decreases.">
      <div className="grid gap-4 md:grid-cols-3">
        {row('Percentage of a number', [base, 'Number', setBase], [pct, 'Percent', setPct], ofResult)}
        {row('Percentage increase', [incBase, 'Original', setIncBase], [incPct, 'Increase', setIncPct], incResult)}
        {row('Percentage decrease', [decBase, 'Original', setDecBase], [decPct, 'Decrease', setDecPct], decResult)}
      </div>
    </ToolShell>
  );
}

export function TextCaseConverterTool() {
  useSeo({ title: 'Text Case Converter — WebCraft Guide', description: 'Convert text to UPPERCASE, lowercase, Title Case, and Sentence case.', canonicalPath: '/tools/text-case-converter' });
  const [text, setText] = useState('');
  const toTitle = (s: string) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
  const toSentence = (s: string) => s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, (c) => c.toUpperCase());
  const result = { UPPERCASE: text.toUpperCase(), lowercase: text.toLowerCase(), 'Title Case': toTitle(text), 'Sentence case': toSentence(text) };

  return (
    <ToolShell title="Text Case Converter" description="Convert text between common cases.">
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} placeholder="Type or paste text…" className="w-full rounded-xl border border-slate-300 p-4 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {Object.entries(result).map(([label, val]) => (
          <div key={label} className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{label}</h3>
              <button onClick={() => navigator.clipboard.writeText(val)} className="text-xs text-blue-600 hover:underline dark:text-blue-400"><Copy className="inline h-3 w-3" /> Copy</button>
            </div>
            <p className="mt-2 break-words text-sm text-slate-700 dark:text-slate-300">{val || '—'}</p>
          </div>
        ))}
      </div>
      <button onClick={() => setText('')} className="mt-4 inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Trash2 className="h-4 w-4" /> Clear</button>
    </ToolShell>
  );
}

export function JsonFormatterTool() {
  useSeo({ title: 'JSON Formatter — WebCraft Guide', description: 'Format, validate, and beautify JSON with clear error messages.', canonicalPath: '/tools/json-formatter' });
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);

  const format = () => {
    try {
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed, null, 2));
      setError(null);
    } catch (e) {
      setError((e as Error).message);
      setOutput('');
    }
  };

  return (
    <ToolShell title="JSON Formatter" description="Paste JSON to format and validate it. No JavaScript is executed.">
      <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={8} placeholder='{"hello": "world"}' className="w-full rounded-xl border border-slate-300 p-4 font-mono text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
      <div className="mt-3 flex gap-2">
        <button onClick={format} className="rounded-lg bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700">Format</button>
        <button onClick={() => navigator.clipboard.writeText(output)} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Copy className="inline h-4 w-4" /> Copy</button>
        <button onClick={() => { setInput(''); setOutput(''); setError(null); }} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Trash2 className="inline h-4 w-4" /> Clear</button>
      </div>
      {error && <p className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-900/30 dark:text-red-300">Error: {error}</p>}
      {output && (
        <pre className="mt-3 overflow-x-auto rounded-xl bg-slate-900 p-4 text-sm text-slate-100">{output}</pre>
      )}
    </ToolShell>
  );
}

export function HtmlFormatterTool() {
  useSeo({ title: 'HTML Formatter — WebCraft Guide', description: 'Format and beautify basic HTML markup.', canonicalPath: '/tools/html-formatter' });
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');

  const format = () => {
    // Lightweight HTML beautifier: inserts newlines after block tags and indents.
    const tokens = input.replace(/>\s*</g, '><').replace(/</g, '\n<').replace(/>/g, '>\n').split('\n').map((t) => t.trim()).filter(Boolean);
    let depth = 0;
    const lines: string[] = [];
    const voidTags = new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
    for (const tok of tokens) {
      if (tok.startsWith('</')) depth = Math.max(0, depth - 1);
      lines.push('  '.repeat(depth) + tok);
      if (tok.startsWith('<') && !tok.startsWith('</') && !tok.endsWith('/>') && !/^<[^>]+>\s*<\/[^>]+>$/.test(tok)) {
        const m = tok.match(/^<([a-zA-Z0-9]+)/);
        if (m && !voidTags.has(m[1].toLowerCase())) depth += 1;
      }
    }
    setOutput(lines.join('\n'));
  };

  return (
    <ToolShell title="HTML Formatter" description="Format and beautify basic HTML. The HTML is never executed.">
      <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={8} placeholder="<div><p>Hello</p></div>" className="w-full rounded-xl border border-slate-300 p-4 font-mono text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
      <div className="mt-3 flex gap-2">
        <button onClick={format} className="rounded-lg bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700">Format</button>
        <button onClick={() => navigator.clipboard.writeText(output)} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Copy className="inline h-4 w-4" /> Copy</button>
        <button onClick={() => { setInput(''); setOutput(''); }} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Trash2 className="inline h-4 w-4" /> Clear</button>
      </div>
      {output && <pre className="mt-3 overflow-x-auto rounded-xl bg-slate-900 p-4 text-sm text-slate-100">{output}</pre>}
    </ToolShell>
  );
}

function hexToRgb(hex: string): [number, number, number] | null {
  const m = hex.replace('#', '').match(/^([0-9a-f]{6}|[0-9a-f]{3})$/i);
  if (!m) return null;
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1];
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}
function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  h /= 360; s /= 100; l /= 100;
  let r, g, b;
  if (s === 0) { r = g = b = l; }
  else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3); g = hue2rgb(p, q, h); b = hue2rgb(p, q, h - 1 / 3);
  }
  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}
function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map((x) => x.toString(16).padStart(2, '0')).join('');
}

export function ColorConverterTool() {
  useSeo({ title: 'Color Converter — WebCraft Guide', description: 'Convert colors between HEX, RGB, and HSL with a live preview.', canonicalPath: '/tools/color-converter' });
  const [hex, setHex] = useState('#2563eb');
  const [rgb, setRgb] = useState('37, 99, 235');
  const [hsl, setHsl] = useState('217, 91%, 53%');
  const [preview, setPreview] = useState('#2563eb');

  const updateFromHex = (v: string) => {
    setHex(v);
    const c = hexToRgb(v);
    if (c) {
      setRgb(`${c[0]}, ${c[1]}, ${c[2]}`);
      const h = rgbToHsl(c[0], c[1], c[2]);
      setHsl(`${h[0]}, ${h[1]}%, ${h[2]}%`);
      setPreview(v);
    }
  };
  const updateFromRgb = (v: string) => {
    setRgb(v);
    const parts = v.split(',').map((x) => parseInt(x.trim(), 10));
    if (parts.length === 3 && parts.every((x) => !isNaN(x) && x >= 0 && x <= 255)) {
      const h = rgbToHsl(parts[0], parts[1], parts[2]);
      setHsl(`${h[0]}, ${h[1]}%, ${h[2]}%`);
      const hx = rgbToHex(parts[0], parts[1], parts[2]);
      setHex(hx); setPreview(hx);
    }
  };
  const updateFromHsl = (v: string) => {
    setHsl(v);
    const parts = v.split(',').map((x) => parseFloat(x.replace('%', '').trim()));
    if (parts.length === 3 && parts.every((x) => !isNaN(x))) {
      const c = hslToRgb(parts[0], parts[1], parts[2]);
      setRgb(`${c[0]}, ${c[1]}, ${c[2]}`);
      const hx = rgbToHex(c[0], c[1], c[2]);
      setHex(hx); setPreview(hx);
    }
  };

  return (
    <ToolShell title="Color Converter" description="Convert between HEX, RGB, and HSL.">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <ColorField label="HEX" value={hex} onChange={updateFromHex} />
          <ColorField label="RGB" value={rgb} onChange={updateFromRgb} />
          <ColorField label="HSL" value={hsl} onChange={updateFromHsl} />
        </div>
        <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 p-6 dark:border-slate-800">
          <div className="h-32 w-full rounded-xl border border-slate-200 dark:border-slate-700" style={{ backgroundColor: preview }} />
          <p className="mt-3 font-mono text-sm text-slate-700 dark:text-slate-300">{preview}</p>
        </div>
      </div>
    </ToolShell>
  );
}
function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
      <input value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
    </div>
  );
}

export function QrCodeGeneratorTool() {
  useSeo({ title: 'QR Code Generator — WebCraft Guide', description: 'Generate QR codes locally in your browser from text or a URL.', canonicalPath: '/tools/qr-code-generator' });
  const [text, setText] = useState('');
  const [dataUrl, setDataUrl] = useState('');
  const [err, setErr] = useState<string | null>(null);

  const generate = async () => {
    if (!text.trim()) { setErr('Enter text or a URL to generate a QR code.'); setDataUrl(''); return; }
    setErr(null);
    try {
      const QR = await import('qrcode');
      const url = await QR.toDataURL(text, { width: 256, margin: 1 });
      setDataUrl(url);
    } catch (e) {
      setErr((e as Error).message);
    }
  };

  const download = () => {
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl; a.download = 'qr-code.png'; a.click();
  };

  return (
    <ToolShell title="QR Code Generator" description="Generate a QR code from any text or URL — entirely in your browser.">
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3} placeholder="Enter text or URL…" className="w-full rounded-xl border border-slate-300 p-4 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
      <div className="mt-3 flex gap-2">
        <button onClick={generate} className="rounded-lg bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700">Generate</button>
        <button onClick={() => { setText(''); setDataUrl(''); setErr(null); }} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Trash2 className="inline h-4 w-4" /> Clear</button>
        {dataUrl && <button onClick={download} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">Download</button>}
      </div>
      {err && <p className="mt-3 text-sm text-red-600">{err}</p>}
      {dataUrl && <div className="mt-4 flex justify-center"><img src={dataUrl} alt="Generated QR code" className="rounded-xl border border-slate-200 dark:border-slate-800" /></div>}
    </ToolShell>
  );
}

export function ImageSizeCalculatorTool() {
  useSeo({ title: 'Image Size Calculator — WebCraft Guide', description: 'See image width, height, aspect ratio, file size, and type.', canonicalPath: '/tools/image-size-calculator' });
  const [info, setInfo] = useState<{ width: number; height: number; ratio: string; size: string; type: string; name: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErr(null);
    if (!file.type.startsWith('image/')) { setErr('Please select an image file.'); return; }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const w = img.naturalWidth; const h = img.naturalHeight;
      const g = (a: number, b: number): number => (b === 0 ? a : g(b, a % b));
      const d = g(w, h);
      setInfo({
        width: w, height: h,
        ratio: d === 0 ? `${w}:${h}` : `${w / d}:${h / d}`,
        size: file.size < 1024 ? `${file.size} B` : file.size < 1024 * 1024 ? `${(file.size / 1024).toFixed(1)} KB` : `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        type: file.type, name: file.name,
      });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => { setErr('Could not read this image.'); URL.revokeObjectURL(url); };
    img.src = url;
  };

  const fields = info ? [
    { label: 'Width', value: `${info.width}px` },
    { label: 'Height', value: `${info.height}px` },
    { label: 'Aspect ratio', value: info.ratio },
    { label: 'File size', value: info.size },
    { label: 'Image type', value: info.type },
    { label: 'File name', value: info.name },
  ] : [];

  return (
    <ToolShell title="Image Size Calculator" description="Upload an image to see its dimensions, aspect ratio, size, and type — processed locally in your browser.">
      <input type="file" accept="image/*" onChange={onFile} className="block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-blue-600 file:px-4 file:py-2 file:text-sm file:font-medium file:text-white hover:file:bg-blue-700 dark:text-slate-300" />
      {err && <p className="mt-3 text-sm text-red-600">{err}</p>}
      {info && (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {fields.map((f) => (
            <div key={f.label} className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs text-slate-500 dark:text-slate-400">{f.label}</div>
              <div className="mt-1 break-words text-sm font-semibold text-slate-900 dark:text-white">{f.value}</div>
            </div>
          ))}
        </div>
      )}
    </ToolShell>
  );
}

function ToolShell({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <BreadcrumbsSimple title={title} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">{title}</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">{description}</p>
      <div className="mt-6">{children}</div>
    </div>
  );
}
function BreadcrumbsSimple({ title }: { title: string }) {
  return (
    <nav className="text-sm text-slate-500 dark:text-slate-400">
      <ol className="flex flex-wrap items-center gap-1">
        <li><a href="/" className="hover:text-blue-600 dark:hover:text-blue-400">Home</a></li>
        <li><span>/</span></li>
        <li><a href="/tools" className="hover:text-blue-600 dark:hover:text-blue-400">Tools</a></li>
        <li><span>/</span></li>
        <li className="text-slate-700 dark:text-slate-300">{title}</li>
      </ol>
    </nav>
  );
}
