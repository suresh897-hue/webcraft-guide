import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useSeo, SITE_ORIGIN } from '@/context/SeoContext';

export function AboutPage() {
  useSeo({
    title: 'About — WebCraft Guide',
    description: 'WebCraft Guide provides practical educational resources about AI, web development, websites, SEO, and online tools.',
    canonicalPath: '/about',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'WebCraft Guide',
      url: SITE_ORIGIN,
      description: 'Practical educational resources about AI, web development, websites, SEO, and online tools.',
    },
  });
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'About' }]} />
      <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">About WebCraft Guide</h1>
      <p className="mt-4 text-lg text-slate-700 dark:text-slate-300">
        WebCraft Guide provides practical educational resources about AI, web development, websites, SEO, and online tools.
      </p>

      <section className="mt-8">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Mission</h2>
        <p className="mt-2 text-slate-700 dark:text-slate-300">
          Our mission is to make web development and AI approachable for everyone — from complete beginners to working practitioners — through clear, practical, and honest educational content.
        </p>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">What We Cover</h2>
        <ul className="mt-2 list-disc space-y-1 pl-6 text-slate-700 dark:text-slate-300">
          <li>AI tutorials, prompting, coding, and productivity</li>
          <li>Web development: HTML, CSS, JavaScript, React, APIs, databases, and hosting</li>
          <li>Website building with no-code and low-code tools</li>
          <li>SEO basics, technical SEO, and on-page optimization</li>
          <li>Website business: clients, pricing, and maintenance</li>
          <li>Free, privacy-friendly online tools</li>
        </ul>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Editorial Approach</h2>
        <p className="mt-2 text-slate-700 dark:text-slate-300">
          We publish original, reviewed content. We do not publish fake reviews, fake testimonials, fake statistics, or misleading earnings claims. Sample articles on this site are clearly marked as demo content until replaced with reviewed original work.
        </p>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Contact</h2>
        <p className="mt-2 text-slate-700 dark:text-slate-300">
          Have a question or suggestion? <a href="/contact" className="text-blue-600 hover:underline dark:text-blue-400">Get in touch</a>.
        </p>
      </section>
    </div>
  );
}
