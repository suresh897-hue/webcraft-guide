import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import type { Article, Category } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { ArticleCard } from '@/components/ArticleCard';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { getIcon } from '@/lib/icons';
import { useSeo, SITE_ORIGIN } from '@/context/SeoContext';

const categoryTopics: Record<string, string[]> = {
  ai: ['AI tools', 'AI prompting', 'AI coding', 'AI productivity', 'AI website builders'],
  'web-development': ['HTML', 'CSS', 'JavaScript', 'React', 'APIs', 'Databases', 'Hosting'],
  'website-building': ['Website builders', 'Forms', 'Booking systems', 'Admin panels', 'Domains', 'Hosting'],
  seo: ['SEO basics', 'Technical SEO', 'On-page SEO', 'Search Console', 'Website performance'],
  'website-business': ['Finding clients', 'Website pricing', 'Client websites', 'Maintenance', 'Local business websites'],
  javascript: ['Basics', 'DOM', 'Async', 'Patterns', 'Examples'],
};

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<Category | null>(null);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useSeo({
    title: category ? `${category.name} — WebCraft Guide` : 'Category',
    description: category?.description ?? '',
    canonicalPath: `/${slug}`,
    jsonLd: category ? {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_ORIGIN },
        { '@type': 'ListItem', position: 2, name: category.name, item: `${SITE_ORIGIN}/${category.slug}` },
      ],
    } : undefined,
  });

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    (async () => {
      const { data: cat } = await supabase.from('categories').select('*').eq('slug', slug).maybeSingle();
      setCategory(cat as Category | null);
      if (cat) {
        const { data: aData } = await supabase
          .from('articles')
          .select('*, category:categories(*), author:authors(*)')
          .eq('category_id', (cat as Category).id)
          .or('status.eq.published,is_sample.eq.true')
          .order('published_at', { ascending: false, nullsFirst: false });
        setArticles((aData ?? []) as Article[]);
      } else {
        setArticles([]);
      }
      setLoading(false);
    })();
  }, [slug]);

  if (loading) return <div className="mx-auto max-w-6xl px-4 py-20 text-slate-500">Loading…</div>;
  if (!category) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-20">
        <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Category' }]} />
        <h1 className="mt-3 text-2xl font-bold text-slate-900 dark:text-white">Category not found</h1>
        <p className="mt-2 text-slate-600 dark:text-slate-400">No articles found.</p>
      </div>
    );
  }

  const Icon = getIcon(category.icon);
  const topics = categoryTopics[category.slug] ?? [];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: category.name }]} />
      <div className="mt-6 flex items-start gap-4">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400">
          <Icon className="h-6 w-6" />
        </span>
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">{category.name}</h1>
          <p className="mt-1 max-w-2xl text-slate-600 dark:text-slate-400">{category.description}</p>
        </div>
      </div>

      {topics.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {topics.map((t) => (
            <span key={t} className="rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 dark:border-slate-700 dark:text-slate-400">{t}</span>
          ))}
        </div>
      )}

      <h2 className="mt-10 text-xl font-bold text-slate-900 dark:text-white">Articles</h2>
      {articles.length === 0 ? (
        <p className="mt-4 text-slate-500">No articles found in this category yet.</p>
      ) : (
        <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((a) => <ArticleCard key={a.id} article={a} />)}
        </div>
      )}
    </div>
  );
}
