import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, CheckCircle, FileEdit, FolderTree, Wrench, Mail, Inbox } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Stats {
  total: number; published: number; draft: number; categories: number; tools: number; subscribers: number; messages: number;
}

export function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ total: 0, published: 0, draft: 0, categories: 0, tools: 0, subscribers: 0, messages: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [articles, published, drafts, cats, tools, subs, msgs] = await Promise.all([
        supabase.from('articles').select('id', { count: 'exact', head: true }),
        supabase.from('articles').select('id', { count: 'exact', head: true }).eq('status', 'published'),
        supabase.from('articles').select('id', { count: 'exact', head: true }).eq('status', 'draft'),
        supabase.from('categories').select('id', { count: 'exact', head: true }),
        supabase.from('tools').select('id', { count: 'exact', head: true }),
        supabase.from('subscribers').select('id', { count: 'exact', head: true }),
        supabase.from('contact_messages').select('id', { count: 'exact', head: true }),
      ]);
      setStats({
        total: articles.count ?? 0,
        published: published.count ?? 0,
        draft: drafts.count ?? 0,
        categories: cats.count ?? 0,
        tools: tools.count ?? 0,
        subscribers: subs.count ?? 0,
        messages: msgs.count ?? 0,
      });
      setLoading(false);
    })();
  }, []);

  const cards = [
    { label: 'Total Articles', value: stats.total, icon: FileText, to: '/admin/articles' },
    { label: 'Published', value: stats.published, icon: CheckCircle, to: '/admin/articles' },
    { label: 'Drafts', value: stats.draft, icon: FileEdit, to: '/admin/articles' },
    { label: 'Categories', value: stats.categories, icon: FolderTree, to: '/admin/categories' },
    { label: 'Tools', value: stats.tools, icon: Wrench, to: '/admin/tools' },
    { label: 'Subscribers', value: stats.subscribers, icon: Mail, to: '/admin/subscribers' },
    { label: 'Contact Messages', value: stats.messages, icon: Inbox, to: '/admin/messages' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Real values from the database.</p>
      {loading ? (
        <p className="mt-6 text-slate-500">Loading…</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <Link key={c.label} to={c.to} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">{c.value}</span>
                <c.icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{c.label}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
