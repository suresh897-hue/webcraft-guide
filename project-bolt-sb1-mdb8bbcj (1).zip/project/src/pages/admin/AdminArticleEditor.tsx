import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Save, ArrowLeft, Plus, Trash2, AlertTriangle } from 'lucide-react';
import type { Article, ArticleStatus, Author, Category, ContentBlock } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { slugify, excerptFromContent, readingTimeFromText } from '@/lib/format';
import { blocksToPlainText } from '@/components/ArticleContent';

const emptyBlocks: ContentBlock[] = [{ type: 'h2', text: 'Introduction' }, { type: 'p', text: '' }];

export function AdminArticleEditor() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id;
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [slugTouched, setSlugTouched] = useState(false);
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState<ContentBlock[]>(emptyBlocks);
  const [categoryId, setCategoryId] = useState('');
  const [authorId, setAuthorId] = useState('');
  const [featuredImage, setFeaturedImage] = useState('');
  const [status, setStatus] = useState<ArticleStatus>('draft');
  const [publishedAt, setPublishedAt] = useState('');
  const [updatedAt, setUpdatedAt] = useState('');
  const [readingTime, setReadingTime] = useState(1);
  const [seoTitle, setSeoTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');
  const [canonicalUrl, setCanonicalUrl] = useState('');
  const [ogImage, setOgImage] = useState('');
  const [isSample, setIsSample] = useState(false);

  const [categories, setCategories] = useState<Category[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPublishWarning, setShowPublishWarning] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: cats }, { data: auths }] = await Promise.all([
        supabase.from('categories').select('*').order('name'),
        supabase.from('authors').select('*').order('name'),
      ]);
      setCategories((cats ?? []) as Category[]);
      setAuthors((auths ?? []) as Author[]);
      if (!isNew && id) {
        const { data } = await supabase.from('articles').select('*').eq('id', id).maybeSingle();
        const a = data as Article | null;
        if (a) {
          setTitle(a.title); setSlug(a.slug); setExcerpt(a.excerpt ?? '');
          setContent(a.content ?? emptyBlocks);
          setCategoryId(a.category_id ?? '');
          setAuthorId(a.author_id ?? '');
          setFeaturedImage(a.featured_image_url ?? '');
          setStatus(a.status);
          setPublishedAt(a.published_at ? a.published_at.slice(0, 16) : '');
          setUpdatedAt(a.updated_at?.slice(0, 16) ?? '');
          setReadingTime(a.reading_time_minutes ?? 1);
          setSeoTitle(a.seo_title ?? ''); setMetaDescription(a.meta_description ?? '');
          setCanonicalUrl(a.canonical_url ?? ''); setOgImage(a.og_image_url ?? '');
          setIsSample(a.is_sample);
        }
      }
      setLoading(false);
    })();
  }, [id, isNew]);

  const computedSlug = useMemo(() => (slugTouched ? slug : slugify(title)), [slug, slugTouched, title]);
  const computedExcerpt = useMemo(() => excerpt || excerptFromContent(content), [excerpt, content]);
  const computedReading = useMemo(() => readingTime || readingTimeFromText(blocksToPlainText(content)), [readingTime, content]);

  const updateBlock = (i: number, patch: Partial<ContentBlock>) => {
    setContent((prev) => prev.map((b, idx) => (idx === i ? { ...b, ...patch } as ContentBlock : b)));
  };
  const removeBlock = (i: number) => setContent((prev) => prev.filter((_, idx) => idx !== i));
  const addBlock = (type: ContentBlock['type']) => {
    const empty: ContentBlock = type === 'ul' || type === 'ol' ? { type, items: [''] } : type === 'table' ? { type, headers: ['', ''], rows: [['', '']] } : type === 'image' ? { type, url: '', alt: '' } : { type: type as 'p' | 'h2' | 'h3' | 'quote' | 'code', text: '' };
    setContent((prev) => [...prev, empty]);
  };

  const save = async (overrideStatus?: ArticleStatus) => {
    setError(null);
    if (!title.trim()) { setError('Title is required.'); return; }
    const finalSlug = computedSlug || slugify(title);
    if (!finalSlug) { setError('Slug is required.'); return; }
    const finalStatus = overrideStatus ?? status;
    setSaving(true);
    const nowIso = new Date().toISOString();
    const payload = {
      title: title.trim(),
      slug: finalSlug,
      excerpt: computedExcerpt,
      content,
      category_id: categoryId || null,
      author_id: authorId || null,
      featured_image_url: featuredImage || null,
      status: finalStatus,
      published_at: finalStatus === 'published' ? (publishedAt ? new Date(publishedAt).toISOString() : nowIso) : (publishedAt ? new Date(publishedAt).toISOString() : null),
      updated_at: nowIso,
      reading_time_minutes: computedReading,
      seo_title: seoTitle || null,
      meta_description: metaDescription || null,
      canonical_url: canonicalUrl || null,
      og_image_url: ogImage || null,
      is_sample: isSample,
    };
    let res;
    if (isNew) {
      res = await supabase.from('articles').insert(payload).select('id').single();
    } else {
      res = await supabase.from('articles').update(payload).eq('id', id).select('id').single();
    }
    setSaving(false);
    if (res.error) { setError(res.error.message); return; }
    navigate('/admin/articles');
  };

  const requestPublish = () => {
    setShowPublishWarning(true);
  };
  const confirmPublish = () => {
    setShowPublishWarning(false);
    save('published');
  };

  if (loading) return <div className="text-slate-500">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Link to="/admin/articles" className="inline-flex items-center gap-1 text-sm text-slate-600 hover:text-blue-600 dark:text-slate-400"><ArrowLeft className="h-4 w-4" /> Back to articles</Link>
          <h1 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">{isNew ? 'New Article' : 'Edit Article'}</h1>
        </div>
        <div className="flex gap-2">
          <button onClick={() => save('draft')} disabled={saving} className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Save className="inline h-4 w-4" /> Save Draft</button>
          <button onClick={requestPublish} disabled={saving} className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Publish</button>
        </div>
      </div>

      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-900/30 dark:text-red-300">{error}</div>}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card title="Content">
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Article title" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-lg font-semibold outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            <textarea value={excerpt} onChange={(e) => setExcerpt(e.target.value)} placeholder="Excerpt (auto-generated if empty)" rows={2} className="mt-3 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            <div className="mt-4 space-y-2">
              {content.map((b, i) => (
                <BlockEditor key={i} block={b} onChange={(patch) => updateBlock(i, patch)} onRemove={() => removeBlock(i)} />
              ))}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {(['h2', 'h3', 'p', 'quote', 'code', 'ul', 'ol', 'image', 'table'] as const).map((t) => (
                <button key={t} onClick={() => addBlock(t)} className="rounded-lg border border-slate-300 px-2 py-1 text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Plus className="inline h-3 w-3" /> {t}</button>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Publishing">
            <Field label="Status">
              <select value={status} onChange={(e) => setStatus(e.target.value as ArticleStatus)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="scheduled">Scheduled</option>
              </select>
            </Field>
            <Field label="Published at">
              <input type="datetime-local" value={publishedAt} onChange={(e) => setPublishedAt(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="Updated at">
              <input type="datetime-local" value={updatedAt} onChange={(e) => setUpdatedAt(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="Reading time (min)">
              <input type="number" min={1} value={computedReading} onChange={(e) => setReadingTime(Number(e.target.value) || 1)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input type="checkbox" checked={isSample} onChange={(e) => setIsSample(e.target.checked)} /> Mark as sample/demo content
            </label>
          </Card>

          <Card title="Organization">
            <Field label="Category">
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white">
                <option value="">— Select —</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Author">
              <select value={authorId} onChange={(e) => setAuthorId(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white">
                <option value="">— Select —</option>
                {authors.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </Field>
          </Card>

          <Card title="SEO">
            <Field label="URL slug">
              <input value={computedSlug} onChange={(e) => { setSlug(e.target.value); setSlugTouched(true); }} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="Canonical URL">
              <input value={canonicalUrl} onChange={(e) => setCanonicalUrl(e.target.value)} placeholder="https://" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="SEO title">
              <input value={seoTitle} onChange={(e) => setSeoTitle(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="Meta description">
              <textarea value={metaDescription} onChange={(e) => setMetaDescription(e.target.value)} rows={2} className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
          </Card>

          <Card title="Images">
            <Field label="Featured image URL">
              <input value={featuredImage} onChange={(e) => setFeaturedImage(e.target.value)} placeholder="https://" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
            <Field label="Open Graph image URL">
              <input value={ogImage} onChange={(e) => setOgImage(e.target.value)} placeholder="https://" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            </Field>
          </Card>
        </div>
      </div>

      {showPublishWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 dark:bg-slate-900">
            <div className="flex items-center gap-3 text-amber-600"><AlertTriangle className="h-6 w-6" /><h2 className="text-lg font-bold text-slate-900 dark:text-white">Before publishing</h2></div>
            <p className="mt-3 text-sm text-slate-700 dark:text-slate-300">Review this article for accuracy, originality, usefulness, sources, and grammar before publishing.</p>
            <p className="mt-2 text-sm text-slate-700 dark:text-slate-300">Do not publish AI-generated content without human review.</p>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setShowPublishWarning(false)} className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">Cancel</button>
              <button onClick={confirmPublish} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Confirm & Publish</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BlockEditor({ block, onChange, onRemove }: { block: ContentBlock; onChange: (patch: Partial<ContentBlock>) => void; onRemove: () => void }) {
  const label = block.type.toUpperCase();
  return (
    <div className="rounded-xl border border-slate-200 p-3 dark:border-slate-800">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">{label}</span>
        <button onClick={onRemove} className="text-red-600 hover:text-red-700"><Trash2 className="h-4 w-4" /></button>
      </div>
      {block.type === 'ul' || block.type === 'ol' ? (
        <div className="space-y-1">
          {block.items.map((it, i) => (
            <div key={i} className="flex gap-1">
              <input value={it} onChange={(e) => onChange({ items: block.items.map((x, j) => (j === i ? e.target.value : x)) } as Partial<ContentBlock>)} className="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
              <button onClick={() => onChange({ items: block.items.filter((_, j) => j !== i) } as Partial<ContentBlock>)} className="text-red-600"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
          <button onClick={() => onChange({ items: [...block.items, ''] } as Partial<ContentBlock>)} className="text-xs text-blue-600 hover:underline">+ Add item</button>
        </div>
      ) : block.type === 'table' ? (
        <div className="space-y-2 overflow-x-auto">
          <div className="flex gap-1">
            {block.headers.map((h, i) => (
              <input key={i} value={h} onChange={(e) => onChange({ headers: block.headers.map((x, j) => (j === i ? e.target.value : x)) } as Partial<ContentBlock>)} placeholder="Header" className="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-xs font-semibold dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
            ))}
          </div>
          {block.rows.map((row, ri) => (
            <div key={ri} className="flex gap-1">
              {row.map((cell, ci) => (
                <input key={ci} value={cell} onChange={(e) => onChange({ rows: block.rows.map((r, j) => (j === ri ? r.map((c, k) => (k === ci ? e.target.value : c)) : r)) } as Partial<ContentBlock>)} className="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
              ))}
              <button onClick={() => onChange({ rows: block.rows.filter((_, j) => j !== ri) } as Partial<ContentBlock>)} className="text-red-600"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
          <button onClick={() => onChange({ rows: [...block.rows, block.headers.map(() => '')] } as Partial<ContentBlock>)} className="text-xs text-blue-600 hover:underline">+ Add row</button>
        </div>
      ) : block.type === 'image' ? (
        <div className="space-y-2">
          <input value={block.url} onChange={(e) => onChange({ url: e.target.value } as Partial<ContentBlock>)} placeholder="Image URL" className="w-full rounded-lg border border-slate-300 px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <input value={block.alt ?? ''} onChange={(e) => onChange({ alt: e.target.value } as Partial<ContentBlock>)} placeholder="Alt text" className="w-full rounded-lg border border-slate-300 px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <input value={block.caption ?? ''} onChange={(e) => onChange({ caption: e.target.value } as Partial<ContentBlock>)} placeholder="Caption (optional)" className="w-full rounded-lg border border-slate-300 px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </div>
      ) : block.type === 'code' ? (
        <textarea value={block.text} onChange={(e) => onChange({ text: e.target.value } as Partial<ContentBlock>)} rows={4} className="w-full rounded-lg border border-slate-300 px-2 py-1 font-mono text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
      ) : (
        <textarea value={(block as { text: string }).text} onChange={(e) => onChange({ text: e.target.value } as Partial<ContentBlock>)} rows={block.type === 'p' ? 3 : 1} className="w-full rounded-lg border border-slate-300 px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
      )}
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">{title}</h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">{label}</label>
      {children}
    </div>
  );
}
