import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Pencil, Eye, Send, EyeOff, Trash2, AlertTriangle } from 'lucide-react';
import type { Article } from '@/types/models';
import { supabase } from '@/lib/supabase';
import { formatDate } from '@/lib/format';

export function AdminArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Article | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('articles')
      .select('*, category:categories(*), author:authors(*)')
      .order('created_at', { ascending: false });
    setArticles((data ?? []) as Article[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const setStatus = async (a: Article, status: 'published' | 'draft') => {
    const patch: Record<string, unknown> = { status, updated_at: new Date().toISOString() };
    if (status === 'published' && !a.published_at) patch.published_at = new Date().toISOString();
    await supabase.from('articles').update(patch).eq('id', a.id);
    load();
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    await supabase.from('articles').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    setDeleteTarget(null);
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Articles</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Create, edit, publish, and delete articles.</p>
        </div>
        <Link to="/admin/articles/new" className="inline-flex items-center gap-1 rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"><Plus className="h-4 w-4" /> New Article</Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <table className="w-full text-sm">
          <thead className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-500 dark:border-slate-800">
            <tr>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Author</th>
              <th className="px-4 py-3">Published</th>
              <th className="px-4 py-3">Updated</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="px-4 py-6 text-center text-slate-500">Loading…</td></tr>
            ) : articles.length === 0 ? (
              <tr><td colSpan={7} className="px-4 py-6 text-center text-slate-500">No articles yet.</td></tr>
            ) : articles.map((a) => (
              <tr key={a.id} className="border-b border-slate-100 last:border-0 dark:border-slate-800">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-slate-900 dark:text-white">{a.title}</span>
                    {a.is_sample && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold uppercase text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">Sample</span>}
                  </div>
                </td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{a.category?.name ?? '—'}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={a.status} />
                </td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{a.author?.name ?? '—'}</td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{formatDate(a.published_at) || '—'}</td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{formatDate(a.updated_at)}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <Link to={`/admin/articles/${a.id}/edit`} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" title="Edit"><Pencil className="h-4 w-4" /></Link>
                    <Link to={`/tutorials/${a.slug}`} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" title="Preview"><Eye className="h-4 w-4" /></Link>
                    {a.status === 'published' ? (
                      <button onClick={() => setStatus(a, 'draft')} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" title="Unpublish"><EyeOff className="h-4 w-4" /></button>
                    ) : (
                      <button onClick={() => setStatus(a, 'published')} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" title="Publish"><Send className="h-4 w-4" /></button>
                    )}
                    <button onClick={() => setDeleteTarget(a)} className="rounded-lg p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30" title="Delete"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 dark:bg-slate-900">
            <div className="flex items-center gap-3 text-red-600"><AlertTriangle className="h-6 w-6" /><h2 className="text-lg font-bold text-slate-900 dark:text-white">Delete article?</h2></div>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-400">“{deleteTarget.title}” will be permanently deleted. This cannot be undone.</p>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setDeleteTarget(null)} className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">Cancel</button>
              <button onClick={confirmDelete} disabled={deleting} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60">{deleting ? 'Deleting…' : 'Delete'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    published: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',
    draft: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    scheduled: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  };
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${map[status] ?? map.draft}`}>{status}</span>;
}
