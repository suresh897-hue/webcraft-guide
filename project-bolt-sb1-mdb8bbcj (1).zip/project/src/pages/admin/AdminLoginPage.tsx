import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Code2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useSeo } from '@/context/SeoContext';

export function AdminLoginPage() {
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useSeo({ title: 'Admin Login — WebCraft Guide', description: 'Sign in to the WebCraft Guide admin dashboard.', canonicalPath: '/admin/login' });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); setInfo(null); setSubmitting(true);
    if (mode === 'signin') {
      const { error } = await signIn(email, password);
      setSubmitting(false);
      if (error) setError(error);
      else navigate('/admin');
    } else {
      const { error } = await signUp(email, password);
      setSubmitting(false);
      if (error) setError(error);
      else setInfo('Account created. If email confirmation is off, you can now sign in.');
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 py-12">
      <Link to="/" className="mb-6 flex items-center gap-2 font-bold text-slate-900 dark:text-white">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white"><Code2 className="h-5 w-5" /></span>
        WebCraft Guide
      </Link>
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">{mode === 'signin' ? 'Admin Sign In' : 'Create Admin Account'}</h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Access the WebCraft Guide dashboard.</p>
        <form onSubmit={submit} className="mt-5 space-y-3">
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          {error && <p className="text-xs text-red-600">{error}</p>}
          {info && <p className="text-xs text-green-600">{info}</p>}
          <button disabled={submitting} className="w-full rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">
            {submitting ? 'Please wait…' : mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>
        </form>
        <p className="mt-4 text-center text-xs text-slate-500">
          {mode === 'signin' ? (
            <>No account? <button className="text-blue-600 hover:underline" onClick={() => { setMode('signup'); setError(null); setInfo(null); }}>Create one</button></>
          ) : (
            <>Already have an account? <button className="text-blue-600 hover:underline" onClick={() => { setMode('signin'); setError(null); setInfo(null); }}>Sign in</button></>
          )}
        </p>
      </div>
      <p className="mt-6 max-w-sm text-center text-xs text-slate-400">
        The first account you create becomes your administrator. Keep your credentials safe — they are not stored in the code.
      </p>
    </div>
  );
}
