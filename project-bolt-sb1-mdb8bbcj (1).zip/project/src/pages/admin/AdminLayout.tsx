import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import {
  LayoutDashboard, FileText, FolderTree, Tags, Image as ImageIcon, Wrench,
  Users, Search, Settings, Megaphone, Mail, LogOut, Menu, X, Code2, Home,
} from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useSettings } from '@/context/SettingsContext';

const items = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/articles', label: 'Articles', icon: FileText },
  { to: '/admin/categories', label: 'Categories', icon: FolderTree },
  { to: '/admin/tags', label: 'Tags', icon: Tags },
  { to: '/admin/media', label: 'Media', icon: ImageIcon },
  { to: '/admin/tools', label: 'Tools', icon: Wrench },
  { to: '/admin/authors', label: 'Authors', icon: Users },
  { to: '/admin/seo', label: 'SEO', icon: Search },
  { to: '/admin/settings', label: 'Site Settings', icon: Settings },
  { to: '/admin/ads', label: 'Ad Settings', icon: Megaphone },
  { to: '/admin/subscribers', label: 'Subscribers', icon: Mail },
  { to: '/admin/messages', label: 'Contact Messages', icon: Mail },
];

export function AdminLayout() {
  const { signOut, user } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/admin/login');
  };

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <Link to="/admin" className="flex items-center gap-2 px-4 py-4 font-bold text-slate-900 dark:text-white">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white"><Code2 className="h-5 w-5" /></span>
        {settings.site_name}
      </Link>
      <nav className="flex-1 space-y-1 overflow-y-auto px-2">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            end={it.end}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium ${
                isActive ? 'bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400'
                  : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              }`
            }
          >
            <it.icon className="h-4 w-4" /> {it.label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-slate-200 p-3 dark:border-slate-800">
        <p className="truncate px-2 text-xs text-slate-500">{user?.email}</p>
        <div className="mt-2 flex gap-2">
          <Link to="/" className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-slate-200 px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"><Home className="h-3 w-3" /> View site</Link>
          <button onClick={handleSignOut} className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-slate-200 px-2 py-1.5 text-xs text-red-600 hover:bg-red-50 dark:border-slate-700 dark:hover:bg-red-900/30"><LogOut className="h-3 w-3" /> Sign out</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 bg-white md:block dark:border-slate-800 dark:bg-slate-900">
        <SidebarContent />
      </aside>
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <SidebarContent />
          </aside>
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 items-center justify-between border-b border-slate-200 bg-white px-4 dark:border-slate-800 dark:bg-slate-900">
          <button onClick={() => setOpen(true)} className="rounded-lg p-2 text-slate-700 md:hidden dark:text-slate-300"><Menu className="h-5 w-5" /></button>
          <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Admin Dashboard</span>
          {open && <button onClick={() => setOpen(false)} className="rounded-lg p-2 text-slate-700 md:hidden dark:text-slate-300"><X className="h-5 w-5" /></button>}
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
