import { useEffect, useState } from 'react';
import { Trash2, Image as ImageIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { MediaItem } from '@/types/models';

export function AdminMediaPage() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [url, setUrl] = useState('');
  const [alt, setAlt] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    const { data } = await supabase.from('article_media').select('*').order('created_at', { ascending: false });
    setItems((data ?? []) as MediaItem[]);
  };
  useEffect(() => { load(); }, []);

  const addByFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    const { data: up, error: upErr } = await supabase.storage.from('media').upload(`${Date.now()}-${file.name}`, file);
    if (upErr) {
      // Storage bucket may not exist — fall back to recording metadata only
      setError('Storage upload failed. The "media" bucket may not be configured in Supabase. You can still add media by URL.');
      return;
    }
    const { data: pub } = supabase.storage.from('media').getPublicUrl(up.path);
    await supabase.from('article_media').insert({
      url: pub.publicUrl, file_name: file.name, file_type: file.type, size_bytes: file.size, alt_text: alt || file.name,
    });
    setAlt(''); load();
  };

  const addByUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    await supabase.from('article_media').insert({ url: url.trim(), file_name: url.trim().split('/').pop(), alt_text: alt });
    setUrl(''); setAlt(''); load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this media item?')) return;
    await supabase.from('article_media').delete().eq('id', id); load();
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Media</h1>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Add images by URL or upload. Uploads require a Supabase storage bucket named "media".</p>

      {error && <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-700 dark:border-amber-900 dark:bg-amber-900/30 dark:text-amber-300">{error}</div>}

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <form onSubmit={addByUrl} className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">Add by URL</h2>
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/image.jpg" className="mb-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <input value={alt} onChange={(e) => setAlt(e.target.value)} placeholder="Alt text" className="mb-3 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <button className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Add media</button>
          <div className="mt-4 border-t border-slate-200 pt-4 dark:border-slate-800">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">Or upload a file</label>
            <input type="file" accept="image/*" onChange={addByFile} className="mt-1 block w-full text-xs text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-blue-600 file:px-3 file:py-1.5 file:text-white dark:text-slate-300" />
          </div>
        </form>

        <div className="lg:col-span-2 grid grid-cols-2 gap-4 sm:grid-cols-3">
          {items.length === 0 ? <p className="col-span-full text-slate-500">No media yet.</p> : items.map((m) => (
            <div key={m.id} className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
              <div className="aspect-square overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800">
                {m.url.match(/\.(jpg|jpeg|png|gif|webp|svg)/i) ? (
                  <img src={m.url} alt={m.alt_text ?? ''} className="h-full w-full object-cover" loading="lazy" />
                ) : <ImageIcon className="m-auto h-8 w-8 text-slate-400" />}
              </div>
              <p className="mt-2 truncate text-xs text-slate-600 dark:text-slate-400">{m.alt_text ?? m.file_name}</p>
              <div className="mt-1 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">{m.file_type ?? 'file'}</span>
                <button onClick={() => remove(m.id)} className="text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
