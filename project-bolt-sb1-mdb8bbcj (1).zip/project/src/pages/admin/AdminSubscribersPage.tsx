import { useEffect, useState } from 'react';
import { Trash2, Mail } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatDate } from '@/lib/format';
import type { Subscriber } from '@/types/models';

export function AdminSubscribersPage() {
  const [items, setItems] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('subscribers').select('*').order('created_at', { ascending: false });
    setItems((data ?? []) as Subscriber[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const remove = async (id: string) => { if (!confirm('Remove this subscriber?')) return; await supabase.from('subscribers').delete().eq('id', id); load(); };
  const exportCsv = () => {
    const csv = 'email,subscribed_at\n' + items.map((s) => `${s.email},${s.created_at}`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'subscribers.csv'; a.click();
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Subscribers</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{items.length} subscriber{items.length === 1 ? '' : 's'}.</p>
        </div>
        {items.length > 0 && <button onClick={exportCsv} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">Export CSV</button>}
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        {loading ? <p className="p-6 text-center text-slate-500">Loading…</p> : items.length === 0 ? (
          <p className="p-6 text-center text-slate-500">No subscribers yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 text-left text-xs uppercase text-slate-500 dark:border-slate-800"><tr><th className="px-4 py-3">Email</th><th className="px-4 py-3">Subscribed</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
            <tbody>
              {items.map((s) => (
                <tr key={s.id} className="border-b border-slate-100 last:border-0 dark:border-slate-800">
                  <td className="px-4 py-3 font-medium text-slate-900 dark:text-white"><Mail className="mr-2 inline h-4 w-4 text-slate-400" />{s.email}</td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{formatDate(s.created_at)}</td>
                  <td className="px-4 py-3 text-right"><button onClick={() => remove(s.id)} className="rounded-lg p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30"><Trash2 className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
