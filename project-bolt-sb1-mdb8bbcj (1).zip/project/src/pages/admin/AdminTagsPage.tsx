import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { slugify } from '@/lib/format';
import type { Tag } from '@/types/models';

export function AdminTagsPage() {
  const [items, setItems] = useState<Tag[]>([]);
  const [name, setName] = useState('');

  const load = async () => {
    const { data } = await supabase.from('tags').select('*').order('name');
    setItems((data ?? []) as Tag[]);
  };
  useEffect(() => { load(); }, []);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await supabase.from('tags').insert({ name: name.trim(), slug: slugify(name) });
    setName(''); load();
  };
  const remove = async (id: string) => {
    if (!confirm('Delete this tag?')) return;
    await supabase.from('tags').delete().eq('id', id); load();
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Tags</h1>
      <form onSubmit={add} className="mt-6 flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tag name" className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        <button className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"><Plus className="inline h-4 w-4" /> Add</button>
      </form>
      <div className="mt-6 flex flex-wrap gap-2">
        {items.length === 0 ? <p className="text-slate-500">No tags yet.</p> : items.map((t) => (
          <span key={t.id} className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1 text-sm text-slate-700 dark:border-slate-700 dark:text-slate-300">
            {t.name}
            <button onClick={() => remove(t.id)} className="text-red-600"><Trash2 className="h-3 w-3" /></button>
          </span>
        ))}
      </div>
    </div>
  );
}
