import { useEffect, useState } from 'react';
import { Trash2, Mail, MailOpen, Inbox } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatDate } from '@/lib/format';
import type { ContactMessage } from '@/types/models';

export function AdminMessagesPage() {
  const [items, setItems] = useState<ContactMessage[]>([]);
  const [selected, setSelected] = useState<ContactMessage | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('contact_messages').select('*').order('created_at', { ascending: false });
    setItems((data ?? []) as ContactMessage[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const toggleRead = async (m: ContactMessage) => {
    await supabase.from('contact_messages').update({ is_read: !m.is_read }).eq('id', m.id);
    load();
    setSelected((s) => (s && s.id === m.id ? { ...s, is_read: !m.is_read } : s));
  };
  const remove = async (id: string) => { if (!confirm('Delete this message?')) return; await supabase.from('contact_messages').delete().eq('id', id); setSelected(null); load(); };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Contact Messages</h1>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{items.length} message{items.length === 1 ? '' : 's'}.</p>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
          {loading ? <p className="p-6 text-center text-slate-500">Loading…</p> : items.length === 0 ? (
            <p className="flex flex-col items-center gap-2 p-10 text-center text-slate-500"><Inbox className="h-8 w-8" /> No messages yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">
              {items.map((m) => (
                <li key={m.id}>
                  <button onClick={() => { setSelected(m); if (!m.is_read) toggleRead(m); }} className={`flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800 ${selected?.id === m.id ? 'bg-blue-50 dark:bg-slate-800' : ''}`}>
                    {m.is_read ? <MailOpen className="mt-0.5 h-4 w-4 text-slate-400" /> : <Mail className="mt-0.5 h-4 w-4 text-blue-600" />}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-900 dark:text-white">{m.subject}</p>
                      <p className="truncate text-xs text-slate-500">{m.name} · {m.email}</p>
                      <p className="mt-0.5 text-xs text-slate-400">{formatDate(m.created_at)}</p>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          {selected ? (
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">{selected.subject}</h2>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">From {selected.name} &lt;{selected.email}&gt;</p>
                  <p className="text-xs text-slate-400">{formatDate(selected.created_at)}</p>
                </div>
                <button onClick={() => remove(selected.id)} className="rounded-lg p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30"><Trash2 className="h-4 w-4" /></button>
              </div>
              <p className="mt-4 whitespace-pre-wrap text-sm text-slate-700 dark:text-slate-300">{selected.message}</p>
              <a href={`mailto:${selected.email}?subject=Re: ${encodeURIComponent(selected.subject)}`} className="mt-6 inline-flex items-center gap-1 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"><Mail className="h-4 w-4" /> Reply by email</a>
            </div>
          ) : <p className="text-sm text-slate-500">Select a message to read it.</p>}
        </div>
      </div>
    </div>
  );
}
