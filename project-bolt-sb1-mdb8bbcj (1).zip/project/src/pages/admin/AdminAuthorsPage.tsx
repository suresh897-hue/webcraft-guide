import { useEffect, useState } from 'react';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Author } from '@/types/models';

export function AdminAuthorsPage() {
  const [items, setItems] = useState<Author[]>([]);
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [avatar, setAvatar] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const load = async () => {
    const { data } = await supabase.from('authors').select('*').order('name');
    setItems((data ?? []) as Author[]);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload = { name: name.trim(), bio, avatar_url: avatar || null };
    if (editingId) await supabase.from('authors').update(payload).eq('id', editingId);
    else await supabase.from('authors').insert(payload);
    setName(''); setBio(''); setAvatar(''); setEditingId(null); load();
  };
  const edit = (a: Author) => { setEditingId(a.id); setName(a.name); setBio(a.bio ?? ''); setAvatar(a.avatar_url ?? ''); };
  const remove = async (id: string) => { if (!confirm('Delete this author?')) return; await supabase.from('authors').delete().eq('id', id); load(); };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Authors</h1>
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <form onSubmit={submit} className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">{editingId ? 'Edit author' : 'Add author'}</h2>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" className="mb-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Bio" rows={3} className="mb-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <input value={avatar} onChange={(e) => setAvatar(e.target.value)} placeholder="Avatar URL (optional)" className="mb-3 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
          <div className="flex gap-2">
            <button className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"><Plus className="inline h-4 w-4" /> {editingId ? 'Update' : 'Add'}</button>
            {editingId && <button type="button" onClick={() => { setEditingId(null); setName(''); setBio(''); setAvatar(''); }} className="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700 dark:border-slate-700 dark:text-slate-300">Cancel</button>}
          </div>
        </form>
        <div className="lg:col-span-2 overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 text-left text-xs uppercase text-slate-500 dark:border-slate-800"><tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Bio</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
            <tbody>
              {items.map((a) => (
                <tr key={a.id} className="border-b border-slate-100 last:border-0 dark:border-slate-800">
                  <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{a.name}</td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-400"><span className="line-clamp-1">{a.bio ?? '—'}</span></td>
                  <td className="px-4 py-3"><div className="flex justify-end gap-1"><button onClick={() => edit(a)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"><Pencil className="h-4 w-4" /></button><button onClick={() => remove(a.id)} className="rounded-lg p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30"><Trash2 className="h-4 w-4" /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
