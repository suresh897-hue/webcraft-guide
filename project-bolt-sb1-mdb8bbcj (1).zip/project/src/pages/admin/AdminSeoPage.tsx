import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useSettings } from '@/context/SettingsContext';

export function AdminSeoPage() {
  const { settings, refresh } = useSettings();
  const [gaId, setGaId] = useState('');
  const [searchConsole, setSearchConsole] = useState('');
  const [defaultSeoTitle, setDefaultSeoTitle] = useState('');
  const [defaultMeta, setDefaultMeta] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setGaId(settings.google_analytics_id ?? '');
    setSearchConsole(settings.search_console_verification ?? '');
    setDefaultSeoTitle(settings.default_seo_title);
    setDefaultMeta(settings.default_meta_description);
  }, [settings]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await supabase.from('site_settings').update({
      google_analytics_id: gaId || null,
      search_console_verification: searchConsole || null,
      default_seo_title: defaultSeoTitle,
      default_meta_description: defaultMeta,
      updated_at: new Date().toISOString(),
    }).eq('id', 1);
    setSaving(false); setSaved(true); refresh();
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">SEO &amp; Analytics</h1>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Analytics scripts are only injected when an ID is configured. Nothing is hard-coded.</p>
      <form onSubmit={save} className="mt-6 max-w-xl space-y-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <Field label="Google Analytics Measurement ID" hint="e.g. G-XXXXXXX. Leave blank to disable analytics.">
          <input value={gaId} onChange={(e) => setGaId(e.target.value)} placeholder="G-XXXXXXX" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </Field>
        <Field label="Google Search Console verification" hint="The content value of the google-site-verification meta tag.">
          <input value={searchConsole} onChange={(e) => setSearchConsole(e.target.value)} placeholder="Verification token" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </Field>
        <Field label="Default SEO title" hint="Used on pages without a custom title.">
          <input value={defaultSeoTitle} onChange={(e) => setDefaultSeoTitle(e.target.value)} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </Field>
        <Field label="Default meta description">
          <textarea value={defaultMeta} onChange={(e) => setDefaultMeta(e.target.value)} rows={2} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </Field>
        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving…' : 'Save'}</button>
        {saved && <span className="ml-3 text-sm text-green-600">Saved.</span>}
      </form>
    </div>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
      {hint && <p className="mb-1 text-xs text-slate-500">{hint}</p>}
      {children}
    </div>
  );
}
