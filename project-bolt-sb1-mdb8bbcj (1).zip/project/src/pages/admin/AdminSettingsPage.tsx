import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useSettings } from '@/context/SettingsContext';
import type { SocialLinks } from '@/types/models';

export function AdminSettingsPage() {
  const { settings, refresh } = useSettings();
  const [form, setForm] = useState({
    site_name: '', site_description: '', logo_url: '', favicon_url: '',
    contact_email: '', footer_text: '', twitter: '', github: '', youtube: '', linkedin: '',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setForm({
      site_name: settings.site_name,
      site_description: settings.site_description,
      logo_url: settings.logo_url ?? '',
      favicon_url: settings.favicon_url ?? '',
      contact_email: settings.contact_email ?? '',
      footer_text: settings.footer_text,
      twitter: settings.social_links?.twitter ?? '',
      github: settings.social_links?.github ?? '',
      youtube: settings.social_links?.youtube ?? '',
      linkedin: settings.social_links?.linkedin ?? '',
    });
  }, [settings]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const social: SocialLinks = {};
    if (form.twitter) social.twitter = form.twitter;
    if (form.github) social.github = form.github;
    if (form.youtube) social.youtube = form.youtube;
    if (form.linkedin) social.linkedin = form.linkedin;
    await supabase.from('site_settings').update({
      site_name: form.site_name, site_description: form.site_description,
      logo_url: form.logo_url || null, favicon_url: form.favicon_url || null,
      contact_email: form.contact_email || null, footer_text: form.footer_text,
      social_links: social, updated_at: new Date().toISOString(),
    }).eq('id', 1);
    setSaving(false); setSaved(true); refresh();
    setTimeout(() => setSaved(false), 3000);
  };

  const set = (k: keyof typeof form, v: string) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Site Settings</h1>
      <form onSubmit={save} className="mt-6 max-w-2xl space-y-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <Row label="Site name"><input value={form.site_name} onChange={(e) => set('site_name', e.target.value)} className="inp" /></Row>
        <Row label="Site description"><textarea value={form.site_description} onChange={(e) => set('site_description', e.target.value)} rows={2} className="inp" /></Row>
        <Row label="Logo URL"><input value={form.logo_url} onChange={(e) => set('logo_url', e.target.value)} placeholder="https://" className="inp" /></Row>
        <Row label="Favicon URL"><input value={form.favicon_url} onChange={(e) => set('favicon_url', e.target.value)} placeholder="https://" className="inp" /></Row>
        <Row label="Contact email"><input value={form.contact_email} onChange={(e) => set('contact_email', e.target.value)} placeholder="you@example.com" className="inp" /></Row>
        <Row label="Footer text"><input value={form.footer_text} onChange={(e) => set('footer_text', e.target.value)} className="inp" /></Row>
        <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">Social links</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <Row label="Twitter / X"><input value={form.twitter} onChange={(e) => set('twitter', e.target.value)} placeholder="https://twitter.com/…" className="inp" /></Row>
            <Row label="GitHub"><input value={form.github} onChange={(e) => set('github', e.target.value)} placeholder="https://github.com/…" className="inp" /></Row>
            <Row label="YouTube"><input value={form.youtube} onChange={(e) => set('youtube', e.target.value)} placeholder="https://youtube.com/…" className="inp" /></Row>
            <Row label="LinkedIn"><input value={form.linkedin} onChange={(e) => set('linkedin', e.target.value)} placeholder="https://linkedin.com/…" className="inp" /></Row>
          </div>
        </div>
        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving…' : 'Save settings'}</button>
        {saved && <span className="ml-3 text-sm text-green-600">Saved.</span>}
      </form>
      <style>{`.inp{width:100%;border-radius:0.5rem;border:1px solid rgb(203 213 225);padding:0.5rem 0.75rem;font-size:0.875rem;outline:none}.dark .inp{background:rgb(30 41 59);border-color:rgb(51 65 85);color:white}`}</style>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>{children}</div>;
}
