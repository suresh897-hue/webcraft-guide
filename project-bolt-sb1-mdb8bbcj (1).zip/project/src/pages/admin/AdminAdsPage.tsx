import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useSettings } from '@/context/SettingsContext';

export function AdminAdsPage() {
  const { settings, refresh } = useSettings();
  const [adsEnabled, setAdsEnabled] = useState(false);
  const [publisherId, setPublisherId] = useState('');
  const [slotIds, setSlotIds] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setAdsEnabled(settings.ads_enabled);
    setPublisherId(settings.adsense_publisher_id ?? '');
    setSlotIds((settings.adsense_slot_ids ?? []).join(', '));
  }, [settings]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await supabase.from('site_settings').update({
      ads_enabled: adsEnabled,
      adsense_publisher_id: publisherId || null,
      adsense_slot_ids: slotIds.split(',').map((s) => s.trim()).filter(Boolean),
      updated_at: new Date().toISOString(),
    }).eq('id', 1);
    setSaving(false); setSaved(true); refresh();
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Ad Settings</h1>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Real AdSense code is only inserted once a valid Publisher ID and slot IDs are provided. Until then, only labeled "Advertisement" placeholders appear when ads are enabled.</p>
      <form onSubmit={save} className="mt-6 max-w-xl space-y-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <label className="flex items-center justify-between">
          <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Ads Enabled</span>
          <button type="button" onClick={() => setAdsEnabled((v) => !v)} className={`relative h-6 w-11 rounded-full transition ${adsEnabled ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'}`}>
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition ${adsEnabled ? 'left-[22px]' : 'left-0.5'}`} />
          </button>
        </label>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">AdSense Publisher ID</label>
          <input value={publisherId} onChange={(e) => setPublisherId(e.target.value)} placeholder="ca-pub-XXXXXXXXXXXXXXXX" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Ad Slot IDs (comma-separated)</label>
          <input value={slotIds} onChange={(e) => setSlotIds(e.target.value)} placeholder="1234567890, 0987654321" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800 dark:text-white" />
        </div>
        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving…' : 'Save'}</button>
        {saved && <span className="ml-3 text-sm text-green-600">Saved.</span>}
      </form>
    </div>
  );
}
