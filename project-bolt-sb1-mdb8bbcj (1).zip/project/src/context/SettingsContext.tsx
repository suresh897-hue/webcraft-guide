import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { SiteSettings } from '@/types/models';
import { supabase } from '@/lib/supabase';

interface SettingsContextValue {
  settings: SiteSettings;
  loading: boolean;
  refresh: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextValue | undefined>(undefined);

const defaultSettings: SiteSettings = {
  id: 1,
  site_name: 'WebCraft Guide',
  site_description: 'Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.',
  logo_url: null,
  favicon_url: null,
  contact_email: null,
  social_links: {},
  google_analytics_id: null,
  search_console_verification: null,
  adsense_publisher_id: null,
  adsense_slot_ids: [],
  ads_enabled: false,
  footer_text: 'Learn AI, web development, SEO, and website building.',
  default_seo_title: 'WebCraft Guide — Learn AI & Web Development',
  default_meta_description: 'Practical tutorials, beginner-friendly guides, and useful tools to help you build better websites.',
  updated_at: new Date().toISOString(),
};

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    const { data, error } = await supabase
      .from('site_settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle();
    if (!error && data) setSettings(data as SiteSettings);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  return (
    <SettingsContext.Provider value={{ settings, loading, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}
