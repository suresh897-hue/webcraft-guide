import { useEffect } from 'react';
import { useSettings } from './SettingsContext';

interface SeoOptions {
  title?: string;
  description?: string;
  canonicalPath?: string;
  ogImage?: string;
  ogType?: 'website' | 'article';
  jsonLd?: object | object[];
}

const SITE_ORIGIN = typeof window !== 'undefined' ? `${window.location.origin}/webcraft-guide` : 'https://suresh897-hue.github.io/webcraft-guide';

function setOrReplace(tag: 'meta' | 'link', attr: string, key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement | HTMLLinkElement>(`${tag}[${attr}="${key}"]`);
  if (!el) {
    el = (tag === 'meta' ? document.createElement('meta') : document.createElement('link')) as HTMLMetaElement | HTMLLinkElement;
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  if (tag === 'meta') (el as HTMLMetaElement).setAttribute('content', content);
  else (el as HTMLLinkElement).setAttribute('href', content);
}

function setMeta(name: string, content: string) { setOrReplace('meta', 'name', name, content); }
function setProp(prop: string, content: string) { setOrReplace('meta', 'property', prop, content); }
function setLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) { el = document.createElement('link'); el.setAttribute('rel', rel); document.head.appendChild(el); }
  el.setAttribute('href', href);
}

export function useSeo(options: SeoOptions) {
  const { settings } = useSettings();

  useEffect(() => {
    const title = options.title ?? settings.default_seo_title ?? 'WebCraft Guide';
    const description = options.description ?? settings.default_meta_description ?? '';
    const canonical = options.canonicalPath ? `${SITE_ORIGIN}${options.canonicalPath}` : SITE_ORIGIN;
    const ogImage = options.ogImage ?? '';

    document.title = title;
    setMeta('description', description);
    setLink('canonical', canonical);
    setMeta('robots', 'index, follow');

    setProp('og:title', title);
    setProp('og:description', description);
    setProp('og:url', canonical);
    setProp('og:type', options.ogType ?? 'website');
    setProp('og:site_name', settings.site_name);
    if (ogImage) setProp('og:image', ogImage);

    setMeta('twitter:card', 'summary_large_image');
    setMeta('twitter:title', title);
    setMeta('twitter:description', description);
    if (ogImage) setMeta('twitter:image', ogImage);

    // Search Console verification
    if (settings.search_console_verification) {
      setMeta('google-site-verification', settings.search_console_verification);
    }

    // JSON-LD
    const existing = document.getElementById('seo-jsonld');
    if (existing) existing.remove();
    if (options.jsonLd) {
      const script = document.createElement('script');
      script.id = 'seo-jsonld';
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify(options.jsonLd);
      document.head.appendChild(script);
    }

    return () => {
      const el = document.getElementById('seo-jsonld');
      if (el) el.remove();
    };
  }, [options.title, options.description, options.canonicalPath, options.ogImage, options.ogType, settings, options.jsonLd]);
}

export { SITE_ORIGIN };
