export type ArticleStatus = 'draft' | 'published' | 'scheduled';

export type ContentBlock =
  | { type: 'h1' | 'h2' | 'h3'; text: string }
  | { type: 'p'; text: string }
  | { type: 'quote'; text: string }
  | { type: 'code'; language?: string; text: string }
  | { type: 'ul' | 'ol'; items: string[] }
  | { type: 'image'; url: string; alt?: string; caption?: string }
  | { type: 'table'; headers: string[]; rows: string[][] };

export interface Author {
  id: string;
  name: string;
  bio: string | null;
  avatar_url: string | null;
  created_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  created_at: string;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  created_at: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: ContentBlock[];
  category_id: string | null;
  author_id: string | null;
  featured_image_url: string | null;
  status: ArticleStatus;
  published_at: string | null;
  updated_at: string;
  reading_time_minutes: number;
  seo_title: string | null;
  meta_description: string | null;
  canonical_url: string | null;
  og_image_url: string | null;
  is_sample: boolean;
  created_at: string;
  // joined fields
  category?: Category | null;
  author?: Author | null;
  tags?: Tag[];
}

export interface MediaItem {
  id: string;
  url: string;
  file_name: string | null;
  file_type: string | null;
  width: number | null;
  height: number | null;
  size_bytes: number | null;
  alt_text: string | null;
  created_at: string;
}

export interface Tool {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  is_active: boolean;
  created_at: string;
}

export interface Subscriber {
  id: string;
  email: string;
  created_at: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface SocialLinks {
  twitter?: string;
  github?: string;
  youtube?: string;
  linkedin?: string;
}

export interface SiteSettings {
  id: number;
  site_name: string;
  site_description: string;
  logo_url: string | null;
  favicon_url: string | null;
  contact_email: string | null;
  social_links: SocialLinks;
  google_analytics_id: string | null;
  search_console_verification: string | null;
  adsense_publisher_id: string | null;
  adsense_slot_ids: string[];
  ads_enabled: boolean;
  footer_text: string;
  default_seo_title: string;
  default_meta_description: string;
  updated_at: string;
}
