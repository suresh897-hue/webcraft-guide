import {
  Sparkles, Code2, LayoutTemplate, Search, Briefcase, Braces, Type, Percent,
  CaseSensitive, Palette, QrCode, Image, Globe, Rss, Mail, type LucideIcon,
} from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  Sparkles, Code2, LayoutTemplate, Search, Briefcase, Braces, Type, Percent,
  CaseSensitive, Palette, QrCode, Image, Globe, Rss, Mail,
};

export function getIcon(name: string | null | undefined): LucideIcon {
  if (!name) return Globe;
  return iconMap[name] ?? Globe;
}
