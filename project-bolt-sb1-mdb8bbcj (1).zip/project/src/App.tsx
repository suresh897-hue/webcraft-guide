import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { PublicLayout } from '@/components/PublicLayout';
import { RequireAuth } from '@/components/RequireAuth';
import { NotFoundPage, ServerErrorPage } from '@/components/ErrorPages';

import { HomePage } from '@/pages/public/HomePage';
import { TutorialsPage } from '@/pages/public/TutorialsPage';
import { ArticlePage } from '@/pages/public/ArticlePage';
import { CategoryPage } from '@/pages/public/CategoryPage';
import { SearchPage } from '@/pages/public/SearchPage';
import { AboutPage } from '@/pages/public/AboutPage';
import { ContactPage } from '@/pages/public/ContactPage';
import { PrivacyPolicyPage, TermsPage, CookiePolicyPage } from '@/pages/public/LegalPages';
import { ToolsPage } from '@/pages/public/ToolsPage';
import {
  WordCounterTool, PercentageCalculatorTool, TextCaseConverterTool,
  JsonFormatterTool, HtmlFormatterTool, ColorConverterTool,
  QrCodeGeneratorTool, ImageSizeCalculatorTool,
} from '@/pages/public/Tools';

import { AdminLoginPage } from '@/pages/admin/AdminLoginPage';
import { AdminLayout } from '@/pages/admin/AdminLayout';
import { AdminDashboard } from '@/pages/admin/AdminDashboard';
import { AdminArticlesPage } from '@/pages/admin/AdminArticlesPage';
import { AdminArticleEditor } from '@/pages/admin/AdminArticleEditor';
import { AdminCategoriesPage } from '@/pages/admin/AdminCategoriesPage';
import { AdminTagsPage } from '@/pages/admin/AdminTagsPage';
import { AdminMediaPage } from '@/pages/admin/AdminMediaPage';
import { AdminToolsPage } from '@/pages/admin/AdminToolsPage';
import { AdminAuthorsPage } from '@/pages/admin/AdminAuthorsPage';
import { AdminSeoPage } from '@/pages/admin/AdminSeoPage';
import { AdminSettingsPage } from '@/pages/admin/AdminSettingsPage';
import { AdminAdsPage } from '@/pages/admin/AdminAdsPage';
import { AdminSubscribersPage } from '@/pages/admin/AdminSubscribersPage';
import { AdminMessagesPage } from '@/pages/admin/AdminMessagesPage';

export default function App() {
  return (
    <BrowserRouter basename="/webcraft-guide">
      <Routes>
        {/* Public site */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/tutorials" element={<TutorialsPage />} />
          <Route path="/tutorials/:slug" element={<ArticlePage />} />
          <Route path="/ai" element={<CategoryPage />} />
          <Route path="/web-development" element={<CategoryPage />} />
          <Route path="/website-building" element={<CategoryPage />} />
          <Route path="/seo" element={<CategoryPage />} />
          <Route path="/website-business" element={<CategoryPage />} />
          <Route path="/javascript" element={<CategoryPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="/tools" element={<ToolsPage />} />
          <Route path="/tools/word-counter" element={<WordCounterTool />} />
          <Route path="/tools/percentage-calculator" element={<PercentageCalculatorTool />} />
          <Route path="/tools/text-case-converter" element={<TextCaseConverterTool />} />
          <Route path="/tools/json-formatter" element={<JsonFormatterTool />} />
          <Route path="/tools/html-formatter" element={<HtmlFormatterTool />} />
          <Route path="/tools/color-converter" element={<ColorConverterTool />} />
          <Route path="/tools/qr-code-generator" element={<QrCodeGeneratorTool />} />
          <Route path="/tools/image-size-calculator" element={<ImageSizeCalculatorTool />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>

        {/* Admin auth */}
        <Route path="/admin/login" element={<AdminLoginPage />} />

        {/* Admin dashboard (protected) */}
        <Route path="/admin" element={<RequireAuth><AdminLayout /></RequireAuth>}>
          <Route index element={<AdminDashboard />} />
          <Route path="articles" element={<AdminArticlesPage />} />
          <Route path="articles/new" element={<AdminArticleEditor />} />
          <Route path="articles/:id/edit" element={<AdminArticleEditor />} />
          <Route path="categories" element={<AdminCategoriesPage />} />
          <Route path="tags" element={<AdminTagsPage />} />
          <Route path="media" element={<AdminMediaPage />} />
          <Route path="tools" element={<AdminToolsPage />} />
          <Route path="authors" element={<AdminAuthorsPage />} />
          <Route path="seo" element={<AdminSeoPage />} />
          <Route path="settings" element={<AdminSettingsPage />} />
          <Route path="ads" element={<AdminAdsPage />} />
          <Route path="subscribers" element={<AdminSubscribersPage />} />
          <Route path="messages" element={<AdminMessagesPage />} />
        </Route>

        {/* 500 fallback */}
        <Route path="/500" element={<ServerErrorPage />} />
      </Routes>
    </BrowserRouter>
  );
}
