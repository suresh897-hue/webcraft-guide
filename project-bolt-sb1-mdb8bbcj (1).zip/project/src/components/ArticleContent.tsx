import type { ContentBlock } from '@/types/models';

export function ArticleContent({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <div className="prose-article">
      {blocks.map((block, i) => {
        switch (block.type) {
          case 'h1':
            return <h1 key={i} className="text-3xl font-bold mt-8 mb-4 text-slate-900 dark:text-white">{block.text}</h1>;
          case 'h2':
            return <h2 key={i} className="text-2xl font-bold mt-8 mb-3 text-slate-900 dark:text-white scroll-mt-24">{block.text}</h2>;
          case 'h3':
            return <h3 key={i} className="text-xl font-semibold mt-6 mb-2 text-slate-900 dark:text-white scroll-mt-24">{block.text}</h3>;
          case 'p':
            return <p key={i} className="my-4 leading-relaxed text-slate-700 dark:text-slate-300">{block.text}</p>;
          case 'quote':
            return (
              <blockquote key={i} className="my-6 border-l-4 border-blue-500 pl-4 italic text-slate-700 dark:text-slate-300">
                {block.text}
              </blockquote>
            );
          case 'code':
            return (
              <pre key={i} className="my-4 overflow-x-auto rounded-xl bg-slate-900 p-4 text-sm text-slate-100">
                <code>{block.text}</code>
              </pre>
            );
          case 'ul':
            return (
              <ul key={i} className="my-4 list-disc space-y-1 pl-6 text-slate-700 dark:text-slate-300">
                {block.items.map((it, j) => <li key={j}>{it}</li>)}
              </ul>
            );
          case 'ol':
            return (
              <ol key={i} className="my-4 list-decimal space-y-1 pl-6 text-slate-700 dark:text-slate-300">
                {block.items.map((it, j) => <li key={j}>{it}</li>)}
              </ol>
            );
          case 'image':
            return (
              <figure key={i} className="my-6">
                <img src={block.url} alt={block.alt ?? ''} loading="lazy" className="w-full rounded-xl" />
                {block.caption && (
                  <figcaption className="mt-2 text-center text-sm text-slate-500">{block.caption}</figcaption>
                )}
              </figure>
            );
          case 'table':
            return (
              <div key={i} className="my-6 overflow-x-auto">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700">
                      {block.headers.map((h, j) => (
                        <th key={j} className="px-3 py-2 text-left font-semibold text-slate-900 dark:text-white">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {block.rows.map((row, r) => (
                      <tr key={r} className="border-b border-slate-100 dark:border-slate-800">
                        {row.map((cell, c) => (
                          <td key={c} className="px-3 py-2 text-slate-700 dark:text-slate-300">{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}

export function extractHeadings(blocks: ContentBlock[]): { id: string; text: string; level: number }[] {
  return blocks
    .filter((b) => b.type === 'h2' || b.type === 'h3')
    .map((b) => {
      const text = (b as { text: string }).text;
      const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      return { id, text, level: b.type === 'h2' ? 2 : 3 };
    });
}

export function blocksToPlainText(blocks: ContentBlock[]): string {
  return blocks
    .map((b) => {
      if ('text' in b) return b.text;
      if ('items' in b) return b.items.join(' ');
      return '';
    })
    .join('\n');
}
