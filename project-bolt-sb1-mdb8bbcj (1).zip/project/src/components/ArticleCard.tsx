import { Link } from 'react-router-dom';
import { Clock, Calendar, ArrowRight } from 'lucide-react';
import type { Article } from '@/types/models';
import { formatDate } from '@/lib/format';

export function ArticleCard({ article }: { article: Article }) {
  const href = `/tutorials/${article.slug}`;
  const categoryName = article.category?.name ?? 'Uncategorized';
  const categorySlug = article.category?.slug ?? 'tutorials';
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <Link to={href} className="block overflow-hidden" aria-label={article.title}>
        {article.featured_image_url ? (
          <img
            src={article.featured_image_url}
            alt={article.title}
            loading="lazy"
            className="aspect-[16/9] w-full object-cover transition duration-300 group-hover:scale-[1.02]"
          />
        ) : (
          <div className="aspect-[16/9] w-full bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-800 dark:to-slate-700" />
        )}
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="mb-2 flex items-center gap-2 text-xs">
          <Link to={`/${categorySlug}`} className="font-medium text-blue-600 hover:underline dark:text-blue-400">
            {categoryName}
          </Link>
          {article.is_sample && (
            <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
              Sample
            </span>
          )}
        </div>
        <h3 className="mb-2 text-lg font-semibold leading-snug text-slate-900 dark:text-white">
          <Link to={href} className="hover:text-blue-600 dark:hover:text-blue-400">{article.title}</Link>
        </h3>
        {article.excerpt && (
          <p className="mb-4 line-clamp-2 text-sm text-slate-600 dark:text-slate-400">{article.excerpt}</p>
        )}
        <div className="mt-auto flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
          {article.author && <span>{article.author.name}</span>}
          <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{formatDate(article.published_at)}</span>
          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{article.reading_time_minutes} min</span>
        </div>
        <Link to={href} className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-blue-600 hover:gap-2 dark:text-blue-400">
          Read Article <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </article>
  );
}
