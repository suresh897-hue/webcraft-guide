import { Link } from 'react-router-dom';
import { ArrowLeft, Home } from 'lucide-react';

export function NotFoundPage({ message = 'Page not found' }: { message?: string }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
      <p className="text-6xl font-bold text-blue-600 dark:text-blue-400">404</p>
      <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">{message}</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">The page you are looking for does not exist or has been moved.</p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
      >
        <Home className="h-4 w-4" /> Back to WebCraft Guide
      </Link>
    </div>
  );
}

export function ServerErrorPage() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
      <p className="text-6xl font-bold text-red-600">500</p>
      <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Something went wrong</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">An unexpected error occurred. Please try again later.</p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
      >
        <ArrowLeft className="h-4 w-4" /> Back home
      </Link>
    </div>
  );
}

export function ToolUnavailable() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Tool unavailable</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-400">This tool is currently unavailable.</p>
      <Link to="/tools" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
        <ArrowLeft className="h-4 w-4" /> All tools
      </Link>
    </div>
  );
}
