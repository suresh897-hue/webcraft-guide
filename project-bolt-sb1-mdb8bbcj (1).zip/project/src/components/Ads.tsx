import { useSettings } from '@/context/SettingsContext';

function AdShell({ label }: { label: string }) {
  return (
    <div className="my-6 flex min-h-[90px] items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 py-4 text-xs uppercase tracking-wider text-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-500">
      Advertisement — {label}
    </div>
  );
}

export function TopAd() {
  const { settings } = useSettings();
  if (!settings.ads_enabled) return null;
  return <AdShell label="Top Banner" />;
}

export function ArticleAd() {
  const { settings } = useSettings();
  if (!settings.ads_enabled) return null;
  return <AdShell label="Article" />;
}

export function InContentAd() {
  const { settings } = useSettings();
  if (!settings.ads_enabled) return null;
  return <AdShell label="In-Content" />;
}

export function SidebarAd() {
  const { settings } = useSettings();
  if (!settings.ads_enabled) return null;
  return <AdShell label="Sidebar" />;
}

export function BottomAd() {
  const { settings } = useSettings();
  if (!settings.ads_enabled) return null;
  return <AdShell label="Bottom Banner" />;
}
