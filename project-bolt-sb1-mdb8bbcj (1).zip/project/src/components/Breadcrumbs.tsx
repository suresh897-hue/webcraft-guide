import { Link } from 'react-router-dom';
import type { Article } from '@/types/models';

export function Breadcrumbs({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-sm text-slate-500 dark:text-slate-400">
      <ol className="flex flex-wrap items-center gap-1">
        {items.map((item, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <span className="text-slate-300 dark:text-slate-600">/</span>}
            {item.to ? (
              <Link to={item.to} className="hover:text-blue-600 dark:hover:text-blue-400">{item.label}</Link>
            ) : (
              <span className="text-slate-700 dark:text-slate-300">{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function SocialShare({ article }: { article: Article }) {
  const url = typeof window !== 'undefined' ? window.location.href : '';
  const text = encodeURIComponent(article.title);
  const encUrl = encodeURIComponent(url);
  const links = [
    { label: 'X', href: `https://twitter.com/intent/tweet?text=${text}&url=${encUrl}` },
    { label: 'Facebook', href: `https://www.facebook.com/sharer/sharer.php?u=${encUrl}` },
    { label: 'LinkedIn', href: `https://www.linkedin.com/sharing/share-offsite/?url=${encUrl}` },
  ];
  const copyLink = async () => {
    try { await navigator.clipboard.writeText(url); } catch { /* ignore */ }
  };
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Share:</span>
      {links.map((l) => (
        <a
          key={l.label}
          href={l.href}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
        >
          {l.label}
        </a>
      ))}
      <button
        onClick={copyLink}
        className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
      >
        Copy link
      </button>
    </div>
  );
}
