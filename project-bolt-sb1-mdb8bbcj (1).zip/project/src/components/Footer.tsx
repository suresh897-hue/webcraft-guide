import { Link } from 'react-router-dom';
import { Code2 } from 'lucide-react';
import { useSettings } from '@/context/SettingsContext';

const quickLinks = [
  { to: '/', label: 'Home' },
  { to: '/tutorials', label: 'Tutorials' },
  { to: '/ai', label: 'AI' },
  { to: '/web-development', label: 'Web Development' },
  { to: '/seo', label: 'SEO' },
  { to: '/tools', label: 'Tools' },
];

const companyLinks = [
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
  { to: '/privacy-policy', label: 'Privacy Policy' },
  { to: '/terms', label: 'Terms' },
  { to: '/cookie-policy', label: 'Cookie Policy' },
];

export function Footer() {
  const { settings } = useSettings();
  const year = new Date().getFullYear();
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <Link to="/" className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white"><Code2 className="h-5 w-5" /></span>
              <span className="text-lg">{settings.site_name}</span>
            </Link>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-400">{settings.footer_text}</p>
          </div>
          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              {quickLinks.map((l) => (
                <li key={l.to}><Link to={l.to} className="text-slate-600 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400">{l.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-900 dark:text-white">Company</h3>
            <ul className="space-y-2 text-sm">
              {companyLinks.map((l) => (
                <li key={l.to}><Link to={l.to} className="text-slate-600 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400">{l.label}</Link></li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-10 border-t border-slate-200 pt-6 text-center text-sm text-slate-500 dark:border-slate-800 dark:text-slate-400">
          © {year} {settings.site_name}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
